title: 跟着DeepLearning背单词-day01
date: '2020-10-19 21:38:56'
updated: '2020-10-19 22:22:49'
tags: [DeepLearning]
permalink: /articles/2020/10/19/1603114736758.html
---
# Notation

符号

This section provides a concise reference describing the notation used throughout this book.

> 这一节提供了贯穿整本书的描述符号的简洁的参考.

If you are unfamiliar with any of the corresponding mathematical concepts.

> 如果你对任何对应的数学概念陌生.

this notation reference may seem intimidating.

> 这个符号参考可能看上去是吓人的.

However, do not despair,we describe most of there ideas in chapter 2-4.

> 然而不用害怕，我们描述大多数想法在第2-4章.

| word | mean |
| - | - |
| section | 部分;段 |
| provides | 提供;规定;供给 |
| concise | 简洁的 |
| reference | 参考 |
| notation | 符号 |
| throughout | 始终 |
| unfamiliar | 陌生 |
| corresponding | 相应的;通信的 |
| mathematical | 数学的 |
| concepts | 概念;学说 |
| intimidating | 吓人的 |

# Numbers And Arrays

数字和数组

$a$: a scalar (integer or real)

> $a$:一个标量(整数或实数)

加粗了: __$a$__ :a vector

> $a$:向量

___A___: a martrix

> ___A___:矩阵

__A__: a tensor

> __A__:张量

$I_n$  Identity matrix with $n$ rows and $n$ columns

> 具有n行n列的恒等矩阵

$I$ Identity matrix with dimensionality implied by context

> 由上下文暗示具有恒等维度的矩阵

$e^{\mathrm{(i)}}$ Standard basis vector [0,...,0,1,0,...,0] with a 1 at postion $i$

> 在位置$i$为1的标准基向量

$diag(a)$: A square diagonal matrix with diagonal entries give by $a$

> 由$a$给出的具有对角线元素的平方对角矩阵

a: a scalar random variable

> 随机变量值的标量

__a__: A vector-valued random variable

> 随机变量值的向量

A: a matrix-valued random variable

> 随机变量值的矩阵

| word | mean |
| - | - |
| scala | 标量 |
| vector | 向量 |
| matrix | 矩阵 |
| tensor | 张量 |
| identity | 同一;一致;恒等;身份 |
| dimensionality | 维度 |
| implied | 陌生;默示;隐含 |
| context | 上下文 |
| standard | 标准 |
| basis | 基础 |
| square | 方 |
| diagonal | 对角线 |
| entries | 条目;元素 |
