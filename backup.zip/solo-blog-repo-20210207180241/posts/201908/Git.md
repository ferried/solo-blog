title: Git
date: '2019-08-19 09:33:22'
updated: '2019-08-19 09:33:22'
tags: [Git]
permalink: /articles/2019/08/19/1566178402477.html
---
![](https://img.hacpai.com/bing/20180418.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Git

git 会用一点， 这篇来深究一下原理

# 三种状态

已提交(committed):存在本地数据库中  
已修改(modified):修改了还没存到数据库中  
已暂存(staged):对一个已修改文件做了标记,包含在下次提交的快照中

# 三个工作区

仓库,工作目录,暂存区

# 本地仓库

初始化仓库:`git init`  
追踪:`git add`  
克隆线上:`git clone http://...`  
检查状态:`git status`  
检查状态(easy):`git status --short`  
未暂存文件更新的部分:`git diff`  
已暂存文件下次提交部分:`git diff --staged`  
提交暂存到仓库:`git commit`  
提交暂存到仓库并加入描述:`git commit -m 'desc'`  
跳过暂存直接提交:`git commit -a`  
移除文件:`git rm part`  
移除暂存的文件:`git rm -f part`  
移除但不删除:`git rm --cached part`  
移动文件:`git mv part part`  
历史记录:`git log`  
历史记录差异:`git log -p 2`  
历史记录简略统计:`git log --stat`  
历史记录格式:`git log --pretty=oneline/short/full`  
历史纪律格式化:`git log --pretty=format: "%h - %an, %ar : %s`

```command
git log
    -p:按补丁格式显示差异
    --stat:每次更新的文件修改统计信息
    --shortstat:只简要信息
    --name-only:仅在提交信息后显示已修改的文件清单
    --name-status:显示新增修改删除的文件清单
    --abbrev-commit:仅显示前几个字符
    --relative-date:使用较短的相对时间显示
    --graph:使用图形显示
    -(n):最近提交的n条
    --since,--after:显示指定时间之后的提交
    --until,--before:显示指定时间之前的提交
    --online --decorate
    --author:显示指定作者相关的提交
    --committer:指定提交者相关的提交
    --since=2.weeks:显示两周以前的提交
    --grep:显示指定关键字的提交
    -S:显示添加或移除了某个关键字的提交
```


重新提交:`git commit --amend`  
取消暂存:`git reset HEAD CONTRIBUTING.md`  
撤销修改:`git checkout -- CONTRIBUTING.md`

# 远程仓库

查看  远程仓库:`git remote`  
查看远程仓库 url:`git remote -v`  
添加远程仓库:`git remote add <shortname> <url>`  
拉取仓库中自己没有的信息:`git fetch <shortname>`  
推送到远程仓库:`git push origin master`  
查看远程仓库:`git remote show <remote-name>`  
重命名远程仓库:`git remote rename <oldname> <newname>`  
删除远程仓库:`git remote rm <name>`

# 打标签

列出标签:`git tag`  
列出对应版本标签:`git tag -l 'v1.0.0'`  
附注标签:`git tag -a v1.4 -m 'version 1.4'`  
查看版本:`git show v1.4`  
轻量标签:`git tag v1.4`  
修补标签:`git tag -a v1.4 <hashvalue>`  
共享标签:`git push origin v1.5`  
推所有标签:`git push origin --tags`  
检出  标签:`git checkout -b <branch> <tag>`

# 分支

1.`git`保存完整文件快照而非差异  
2.`git commit`保存一个提交对象,指针指向暂存区快照  
3.`git commit`会计算每一个字目录的校验(SHA-1)和,然后将校验和保存为树对象._指针_  
4.切换的`^HEAD`的指向的快照

创建分支:`git branch <branchName>`  
切换:`git checkout <branchName>`  
分支最后一次提交:`git branch -v`  
查看合并到本分支的分支:`git branch --merged`  
查看所有包含未合并本分支的分支:`git branch --no-merged`  
 删除分支:`git branch -d <branchName>`

远程分支
同样是`^HEAD`指向了远程快照
查看远程引用:`git ls-remote`  
查看远程分支更多信息:`git remote show`

推送
推送到远程分支:`git push origin <branchName>`  
推送本地分支到远程分支:`git push origin <originBranch>:<localBranch>`

跟踪分支
当`clone`一个仓库时会自动创建一个跟踪`origin/master`的`master`分支,跟踪分支标明远程分支关联的本地分支  
修改跟踪的上游分支:`git branch -u origin/master`  
或者:`git branch --set-upstream-to origin/master`

拉取分支  
pull 会改变工作目录,抓上游最新分支代码并且合并到本地当前分支  
拉取:`git pull`  

删除远程分支  
删除远程分支:`git push origin --delete <branchName>`  

# 变基

场景:feat/add 分支和 hot/fix 分支的指针指向master分支,如果使用merge，那么会进行一个三方合并变成一个新的提交,如果使用变基,那么在任一分支上也可以将其它分支的修改应用到本分支上

```git
git checkout  feat/add
git rebase master
```

`git rebase <baseBranch> <toBranch>`

# 忽略列表

创建.gitignore 文件  
.a : .a 后缀文件不跟踪  
.b : .b 后缀文件不跟踪  
c/ : c 目录下的不跟踪

# 可选command列表

配置:`git config`  
帮助:`git help <command>`  
初始化:`git init`  
克隆:`git clone`  
添加:`git add`  
状态查看:`git status`  
差异查看:`gti diff`  
工具差异查看:`git difftool`  
提交:`git commit`  
回滚:`git reset`  
删除:`git rm`  
移动:`git mv`  
清理:`git clean`  
分支:`git branch`  
检出:`git checkout`  
合并:`git merge`  
工具合并:`git mergetool`  
日志:`git log`  
临时保存:`git stash`  
打标签:`git tag`  
拉取最新信息:`git fetch`  
直接拉取并合并:`git pull`  
推送:`git push`  
记录管理:`git remote`  
创建指定快照的归档文件:`git archive`  
单仓库里的其它外部仓库:`git submodule`  
查看分支情况:`git show`  
日志:`git shortlog`  
二分查找:`git bisect`  
查看任意一行最后的变更信息：`git blame`  
查找任意字符串(正则):`git grep`  
变基:`git rebase`  
撤销:`git revert`