title: 速览LUA
date: '2019-09-24 13:58:09'
updated: '2019-09-27 18:10:00'
tags: [Lua]
permalink: /articles/2019/09/24/1569304689336.html
---
![image.png](https://img.hacpai.com/file/2019/09/image-96058e03.png)

# LUA

这个语言学来搞搞 WOW 插件,有兴趣可以一起合作 &lt;harlancui@outlook.com&gt;

格瑞姆巴托 120 兽王猎人 天干
格瑞姆巴托 120 恶魔猎手 罗晓黑

## 1.数据类型

8 种类型

```lua
--string
type("hello world") 
--number
type(10.4)
--function
type(print)
--boolean
type(true)
--nil
type(nil)
--userdata 自定义类型
--thread 线程
--table 表
```

## 2.算数操作符

```lua
--二元 + - * / ^ %
--一元 -
```

```lua
x = math.pi
print(x-x%0.01)
```

## 3.关系操作符

```
--运算结果为true/false
<
>
<=
>=
~=
```

```lua
a ={} ;a.x = 1; a.y =0
b={};b.x=1;b.y=0
c=a

--true
a==c 
--false
a==b
--true
a~=b
```

## 4.逻辑操作符

and 第一个操作数为假返回第一个操作数
or 第一个操作数为真返回第一个操作数

```lua
--5
4 and 5
--nil
nil and 13
--false
false and 13
--4
4 or 5
--5
false or 5
```

```lua
if not x then x=v end
max = (x>y) and x or y
not nil
not false
not not null
not not no null
```

## 4.字符串连接

```lua
print("hello".."World")
a = "hello"
print(a.."World)
```

## 5.table

```lua
days = {"Sunday","Monday","Tuesday"}
a={x=10,y=20}
days[1]
days[2]
a.x
a.y
w={x=0,y=0,label="console"}
x={math.sin(0),math.sin(1),math.sin(2)}
w[1]="another field"
x.f=w
```

## 6.赋值

```lua
a = "hello" .. "world"
t.n = t.n+1
a,b = 10,2*x
x,y = y,x
a[i],a[j] = a[j],a[i]
a,b,c = 0,1
c == nil
```

## 7.局部变量

```lua
--global
j = 10
--local
local i = 1

x = 10
local i = 1
while i <= x do
	local x = i*2
-- 2,4,6,8
	print(x)
end


if i>20 then
	local x
	x = 20
--22
	print(x +2)
else
--10
	print(x)
end
```

# 8.控制结构

```lua
if a<0 then a=0 end

if a<b then return a else return b end

if line>MAXLINES then
	showpage()
	line = 0
end	

if xxx
	xxx
elseif
	xxx
elseif
	xxx
else
	xxx
end
```

```lua
local i =1
while a[i] do print(a[i]) end

--当until条件达成则不在循环
repeat
	line = io.read()
until line ~= ""
print(line)
```

```lua
for var = exp1,exp2,exp3 do
	xxx
end
```

```lua
--ipairs迭代器(index and value)
for i,v in ipairis(a) do print(v) end
```

## 9.函数

```lua
-- 多返回值
function maximum(a)
	return a+1,a+2
end

--无返回值
function d()
end

--多参数

function add(...)
	local s = 0
	for i,v in iparis{...} do s = s+v end
	return s
end

add(1,2,3,4,5,6,7)
```

```lua
a = {p = print}
a.p(111)
--
foo = function (x) return 2*x end
--
function de(f,delta)
	delta = delta or 1e-4
	return function(x)
			return (f(x+delta)-f(x))/delta
		  end
end

--闭合函数
table.sort(datas,function(d1,d2) return d1>d2 end)

--匿名函数
function newCounter()
local i = 0
	return function()
		i = i + 1
		return i
		end
end
c1 = newCounter()
c1()			
```

```lua
Lib = {}
Lib.foo = function(x,y) return x + y end
Lib = {
	foo = function(x,y) return x + y end
	goo = function(x,y) return x - y end
}
Lib = {}
function Lib.foo(x,y) return x + y end
```

```lua
local f = function(arg)
		xxx
	      end
```

## 10. 迭代器

```lua
function values(t)
	local i = 0
	return function () i = i+1; return t[i] end
end

t = {10,20,30}
iter = values(t)
while true do
	local element = iter()
	if element == nil then break end
	print(element)
end

t = {10,20,30}
	for element in values(t) do
	print(element)
end


local function iter(a,i)
	i = i +1
	local v = a[i]
	if v then
		return i,v
	end
end

function ipairs(a)
	return iter,a,0
end
```

## 11.编译

```lua
-- 从某个模块加载代码块然后调用
function dofile(filename)
	local f = assert(loadfile(filename))
	return f()
end

-- 读取字符串为代码
f = loadstring("i=i+1")
f = function () i=i+1 end

```

## 12.异常处理

```lua
x = io.read()
if not x then error("你输入的是个什么东西") end


if pcall( function ()<body>end) 
then 
	<body> 
else 
	<error> 
end

local status,err = pcall(function() error ({code=121}) end
print(err.code) -> 121
```

## 13.协同

所有有关于协同的函数在 coroutine 的 table 中函数 create 用于创建新的协同程序,返回一个 thread 类型的值,用以表示新的协同程序.

```lua
co = coroutine.create(function()print("hi")end)
```

一个协同程序共有四种不同状态:挂起,运行,死亡,正常

```lua
--查看协同程序状态
print(coroutine.status(co))
```

```lua
--启动一个协同程序
coroutine.resume(co)
```

```lua
--挂起一个协同程序
co = coroutine.create(function()
	for i = 1,10 do
		print("co",i)
-- 挂起,可通过resume在进行激活进入后面的循环
		coroutine.yield()
	end
end


-- 返回值

print(coroutine.resume(coroutine.create(function() return 6,7 end)))
```

## 14. 管道

管道负责将值从一个地方传递给另一个地方，生产者和消费者
(其实就是用函数将两个函数连起来，做到 resume 后有 yield 返回值就行)

```lua
function producer()
	while true do
		local x = io.read()
-- 发送值
		send(x)
	end
end

function consumer()
	while true do
-- 接收值
		local x = receive()
		io.write(x,"\n")
	end
end

function receive()
	local status,value = coroutine.resume(producer)
	return value
end

function send(x)
	coroutine.yield(x)
end
```

## 15.协同迭代器

resume() 和 yield 组成,略过

## 16.多线程

```lua

function receive(connection)
	connection:settimeout(0)
	local s,status,partail = connection:receive(2^10)
	if status === "timeout" then
		coroutine.yield(connection)
	end
	return s or partial,status
end

function download(host,file)
	local c = assert(socket.connect(host,80))
	local count = 0
--c.send(c,"GET"..file.."HTTP/1.0\r\n\r\n")
	c:send("GET"..file.."HTTP/1.0\r\n\r\n")
	while true do
		local s,status,partial = receive(c)
		count = count + #(s or partial)
		if status == "closed" then break end
	end
	c:close()
	print(file,count)
end	


threads ={}
function get(host,file)
-- 起一个协同程序
	local co = coroutine.create(function()download(host,file)end)
-- 将线程和系统程序放入table中
	table.insert(threads,co)
end

function dispatch()
	local i = 1
	while true do
		if threads[i] == nil then
			if threads[i] == nil then break end
			i = 1
		end
-- 如果table当前位置有线程则启动,获取返回值
		local status,res = coroutine.resume(threads[i])
-- 如果没有返回值则删除table中的线程
		if not res then
			table.remove(threads,i)
		else
			i = i+1
		end
	end
end
```

## 17.数组

```lua
-- 新建数组
a = {}
for i=1,1000 do a[i] = i end
-- 长度
print(#a)

a={}   
for i=-5,5,2 do a[i] = [i] end
```

## 18.矩阵多维数组

```lua
mt = {}  
for i=1,N do  
 mt[i] = {}  
 for j=1,M do  
 mt[i][j]=0  
 end  
end

-- 使用矩阵
function mult(a,rowindex,k)
	local row=a[rowindex]
	for i=1,v in pairs(row) do
		row[i] = v * k
	end
end
```

## 19.链表

```lua
--创建链表(双向)
a = {next=b, value=1, pre=nil}
b = {next=c, value=2, pre=a}
c = {next=nil, value=3, pre=b}

local l = a

while l do
	l.value
	l = l.next
end
```

## 20.队列

```lua
function List.new()
	return {}
end

function List.push(list,value)
	list[#list+1]=value
end

function List.pop(list)
	local flag = list[#list]
	list[#list] = nil
	return flag
end


-- 双向队列
funciton List.new()
	return {first = 0 ,last =1 }
end
function List.pushleft(list,value)
	local first = list.first -1
	list.first = first
	list[first] = value
end
```

## 21.集合和无序数组

## 22.字符串缓冲

## 23.图

## 24.数据文件

## 25.串行化

## 26.元表元方法

# 施工中

👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷👷‍♀️👷
