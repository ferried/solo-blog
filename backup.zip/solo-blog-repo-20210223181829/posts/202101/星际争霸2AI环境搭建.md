title: 星际争霸2AI环境搭建
date: '2021-01-01 23:34:55'
updated: '2021-01-01 23:45:39'
tags: [sc2]
permalink: /articles/2021/01/01/1609515295211.html
---
# 0.what

暴雪给策略性即时战略游戏放出了一些接口以用来让开发者研究沙盘推演AI。老早以前的了。今天想着试一试接口，但是下载好游戏玩了一天，晚上才开始搭环境。哈哈哈哈哈

# 1.下载SC2

![image.png](https://b3logfile.com/file/2021/01/image-357e877c.png)

# 2.下载地图

https://github.com/Blizzard/s2client-proto#downloads

![image.png](https://b3logfile.com/file/2021/01/image-d5452b93.png)

https://github.com/deepmind/pysc2

![image.png](https://b3logfile.com/file/2021/01/image-6cbeb9e8.png)

# 3.加入地图

![image.png](https://b3logfile.com/file/2021/01/image-5fee42da.png)

放入 `/Applications/StarCraft\ II/Maps`中

# 4.环境变量

`export SC2PATH=/Applications/StarCraft\ II`

# 5.python环境

`pip3 install pysc2`

# 6.测试

```
python3 -m pysc2.bin.agent --map Simple64
```

# 7.查看demo

![image.png](https://b3logfile.com/file/2021/01/image-d517a69d.png)
