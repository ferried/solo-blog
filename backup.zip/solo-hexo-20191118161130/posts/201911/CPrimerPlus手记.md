title: 《C Primer Plus》手记
date: '2019-11-17 10:44:36'
updated: '2019-11-18 15:19:24'
tags: [C]
permalink: /articles/2019/11/17/1573958676119.html
---
![](https://img.hacpai.com/bing/20190313.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 0.槽
现在的书大都太啰嗦，把读书的人当作傻子。这本书也不例外。
或许详细的API手册才是我所需要的吧。。。

# 1.变量

## 1.1Int
```c
//1.16位计算机 int 区间 为 -32678 - 32677所以ISO C 规定int的取值范围最小为 -32678 - 32677

// erns,dogs 并没有初始化；
int erns;
int cows = 32,goats = 14;
int dogs,cats = 69;

//打印
printf("%d",cats);
//八进制
printf("%o",0144);
// 十六进制
printf("%x",0x64);
//显示前缀
printf("%#o, %#x",0144,0x64);
```
## 1.2修饰符



```c
// short 短 比int范围短
// long 长 比int多
// long long 非常长 至少要64位机器比long长
// unsigned 无符号 非负数情况 unsigned int 0 ~ 65535
// signed 有符号 signed int - 32638 - 32637

long int estine;
long johns;
short int erns;
short ribs;
unsigned int s_count;
unsigned players;
unsigned long headcount;
unsigned short yesvotes;
long long ago;

// unsigned int  %u
printf("%u",null);
// short
printf("%h",null);
// long
printf("%ld",null);
// long long
printf("%lld",null);
// unsigned long
printf("%llu",null);

```

## 1.3char
实际上字符在memory种存储类型为int再经过码表转换成字符
码表:ASCII,kanji,Unicode,GBK,IEC10646
单char占位1bit
```c
char a = 'a';
chat A = 65;
```
非打印字符
```
\a 警报
\b 退格
\f 换页
\n 换行
\r 回车
\t 水平制表
\v 垂直制表
\\ 反斜杠 \
\' 单引号(转义)
\0oo 八进制值
\xhh 十六进制值
```
打印字符
```
printf("%c",'c');
```
## 1.4_Bool

```
true
false
```
## 1.5浮点
```c
float a = 3.11
double b = 3.1415926
long double c = 3.11111111111111111111111111111111111
```
## 1.6类型大小

```c
printf("%d",sizeof(int));
printf("%lld",sizeof(long long int));
```

## 1.7字符串

```c
//  char array = string
char str[40] = "ajskdfjslkafjlsadjfks";
// array size
printf("%d",strlen(str));
```
内存里每一个地址存一个字符，由连续的内存地址存储字符串，遇到\0后结束，\0也占用char array中的一个位置
![image.png](https://img.hacpai.com/file/2019/11/image-2f0af448.png)
```
char a = 'x';
char b[1] = "x";
```

## 1.8常量
```c
#inculde<stdio.h>
#define PI 3.14
int main(){
// 只读
const int i = 0;
printf("%0.2f",PI);
return 0;
}
```
# 2.流控运算符
都差不多:`+ - * /   %  > < =  ++ -- ! ||  & &&` 三元 ?:
```c
while(true){}

for(int i = 0 ;i < 5;i++){}

do{}while(_Bool);

if(_Bool){} else{}

if(_Bool){} else if(_Bool){}

while(true){ if(xxx){ continue;} else if(yyy){break}

switch(xxx){
	case 1:
		break;
	case 2:
		break;
	default:
		break;
}

if(size >12){ goto a}else{goto b};
a:cost = cost*=1.5
b:bill = cost*=2
```

# 3.Input/Output IO

```c
// 获取字符
getchar();
// 输出字符
putchar()
```

```c
// echo
#include<stdio.h>
int main(void){
char ch;
// 如果不输入 # 那么一直读字符
while((ch = getchar()) != '#'){
	// 同时一直输出字符
	putchar(ch);
}
return 0;
}

// 无缓冲
char a = 'a'
// 将字符存入缓冲区
getchar();
```
完全缓冲:当缓冲区被填满时才刷新缓冲区
行缓冲:当出现换行符时刷新缓冲区,enter刷新缓冲区

```c
#include<stdio.h>
#include<stdlib.h>
int main()
{
int ch;
// 文件类型指针
FILE * fp;
char fname[50];
printf("Enter the name of the file");
scanf("%s",fname);
// 打开输入的文件 并用指针指向该文件，以r读权限打开
fp = fopen(fname,"r");
// 如果空指针，证明没有文件
if(fp == NULL){
	printf("no file");
}
// 循环读取文件中的每一个字符最后打印
while((ch = getc(fp))!=EOF){
	putchar(ch);
}
// 关闭文件
fclose(fp);
}
```

# 4.函数

```c
#inculde<stdio.h>
// 书写函数前要声明,不带参数，无返回值
void say(void);
// 返回int值带两个int型参数
int sum(int a,int b);
int main(void){
say();
return 0;
}

void say(){
putchar("H");
}
int sum(int a,int b){return a+b};
```
# 5.指针
```c
// int类型的值
int a = 0;
// &为寻址符，查找a的内存地址
printf("%p",&a);
// 声明指针b
int * b;
// 将a的地址给b
b = a;
// 格式化输出地址
printf("%p",b);
```
# 6.数组二维数组

```c
int main(){
	int a[10] = {1,2,3,4,5,6,7,8,9,0}
	int * b;
	printf("%d",a[0]);
	// 将 a 的首元素地址给了指针b
	b = a;
	// *b 表示 首元素地址所指向的值
	printf("%d",*b);
	// *(b + 1) = a[1]
	printf("%d",*(b+1));
	// *b + 1 = a[0] + 1 = 2
	printf("%d",*b+1);	

	for(int i = 0;i < 10;i++) printf("%d",*(b+i));
}
```
```c
#include<stdio.h>
#define ROWS  3
#define COLS 2

int main(void){
	int array[ROWS][COLS] = {{1,2},{3,4},{5,6}}
	for(int i = 0;i<ROWS;i++){
		for(int j = 0;j<COLS;j++){
			printf("%d",array[i][j]);
		}
	}
	// 创建一个指针，指向一个含有ROS个元素的数组
	int (*pa)[ROWS];
	printf("array[0][0] = %d",**pa);
	// *pa为第一组的地址值,+1为第一组元素的第二个元素的地址值
	printf("array[0][1] = %d",*(*pa+1));
	// pa为第一组元素整体的地址值，+1 移动到第二组元素,外层指针获取第二组第一个元素的地址又加了一个地址所以为第二组元素第二个位置的值
	printf("array[1][1] = %d ",*(*(pa+1)+1));
}


```
注意，指针和数据类型都具有一定的兼容性，具体规则为 
`长度大类型/指针 = 长度小类型/指针`比如`long a; int b = 10; a = b;`
声明指针类型函数
```c
void somefunction(int (*pt)[4]);
void somefunction(int [][4]);
```
PS:变长数组不是说数组的长度可变，而是声明数组时可以使用变量指定数组的维度

# 7.复合字面量
不用声明直接用的变量,也称不上变量。。。
```c
// 没有声明的数组，只能直接传递进函数/表达式
(int[2]){10,20}

int sum(const in ar[],int n);

sum((int [3]){1,2,3},3);
```
# 8.字符串
c里面没有提供字符串的实现，只有字符数组

```c
// 第一位 a ,第二位 "\0"标志字符串结束
char a[1] = "a"
```

```c
#include <stdio.h>
#define MSG "I am a symbolic string constant."
#define MAXLENGTH 81

int main(void) {
 // 声明字符串
  char words[MAXLENGTH] = "I am a string in array.";
 // 用指针直接声明字符串
  const char *p1 = "Somethings is pointing at me.";
// puts,属于stdio.h 的输出函数,只显示字符串
  puts("Here are somt things.");
  puts(MSG);
  puts(words);
  puts(p1);
  words[8] = 'p';
  puts(words);
}
```
指针，和数组指针一个道理
```c
char car[10] = "Tata";
car == &car[0]
*car == 'T'
*(car+1) == car[1] == 'a'
// *pt1可以改变
const char *pt1 = "Some thing is pointing at me"
// ar1不能改变
const char ar1[] = "Some thing is pointing at me"
```
  

```c
#include <stdio.h>
#define SLEN 40
#define LIM 5
int main(void) {
// 5个指针的数组,五个字符串存在静态内存中,指针指向他们
  const char *mytalents[LIM] = {
      "Adding numbers swiftly", "Multiplying accurately", "Stashing data",
      "Following instructions to the letter", "Understanding the C language"};
// 5个数组的数组
  char yourtalents[LIM][SLEN] = {"Walking in a straight line", "Sleeping",
                                 "Watching television", "Mailling letters",
                                 "Reading email"};

  int i;
  puts("Let's compare talents");
  printf("%-36s %-25s \n", "MyTalens", "YourTablens");
  for (i = 0; i < LIM; i++) {
    printf("%-36s %-25s \n", mytalents[i], yourtalents[i]);
  }
  //指针占了40字节而数组占了200字节
  printf("\nsizeof mytalents: %zd, sizeof yourtalents: %zd", sizeof(mytalents),
         sizeof(yourtalents));
}
```
copy
```c
#include<stdio.h>

int main(void)
{
  const char * mesg = "Don't be a fool!";
  const char * copy;
  copy = mesg;

  printf("%s\n",copy);
 // 两个地址都一样，所以字符串没有被copy
 // 只是copy指向了mesg所指向的静态区域的字符串
  printf("%p\n",mesg);
  printf("%p\n",copy);
}
```
## 8.1 函数
gets();
```c
char words[80];
//Input 一些字符读取到words里面
gets(words);
puts("%s",words);
```
# BULLDING
