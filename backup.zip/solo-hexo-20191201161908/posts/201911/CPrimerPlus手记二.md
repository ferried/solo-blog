title: 《C Primer Plus》手记二
date: '2019-11-25 16:05:59'
updated: '2019-11-29 15:21:55'
tags: [C]
permalink: /articles/2019/11/25/1574669159322.html
---
![](https://img.hacpai.com/bing/20181222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# <a href="https://blog.eiyouhe.com/articles/2019/11/17/1573958676119.html">手记一</a>

# 11.文件

```c
// 标准文件
// C会自动打开三个文件 standard input 标准输入 standard output 标准输出 standard
// error output 标准错误输出 standard input  通常为键盘 standard output
// 通常为显示器 通常标准输入为程序提供输入 getchar() scanf() 标准输出
// putchar(),puts(),printf()

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  // 读取文件时存储每个字符
  int ch;
  // 文件指针
  FILE *fp;
  // 记录文件行数
  unsigned long count = 0;
  // 效验传入参数
  if (argc == 0) {
    printf("Usage: %s filename\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  // 效验是否有文件,如果没有,指针就指不上
  if ((fp = fopen(argv[1], "r")) == NULL) {
    printf("Can't Open %s \n", *(argv + 1));
  }
  //循环读 char
  while ((ch = getc(fp)) != EOF) {
    // 输出char
    putc(ch, stdout);
    count++;
  }
  // 关闭文件
  fclose(fp);
  printf("File %s has %lu characters \n", *(argv + 1), count);
  return 0;
}

// 打开方式 fopen 第二个参数
// r 读模式打开
// w 写模式打开,文件不存在则创建一个新的文件
// a 写模式打开,把现有的文件长度截为0,不存在则创建一个新文件
// r+ 更新模式打开,r+w
// w+ 更新模式打开文件,如果文件存在则将其长度截为0,不存在则新建一个文件
// a+ 更新模式打开文件 可以读整个文件但只能在末尾添加内容
// rb 读模式打开二进制
// wb 写模式打开二进制
// x
// rwax 和 b进行组合
File file1.c has 1533 characters
```
getc() 和 putc()
getc() - getchar()
putc() - putchar()
不同点在于要告诉getc和putc函数使用哪一个文件,

```c
//从标准输入中获取一个字符
ch = getchar();
// 从fp指向的文件中获取一个字符
ch = getc(fp);
// 把ch放入fpout指向的文件中
putc(ch,fpout);
```
指向标准文件的指针
```
标准输入 stdin 键盘
标准输出 stdout 显示器
标准错误 stderr 显示器
```

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LEN 40

int main(int argc, char *argv[]) {
  FILE *in, *out;
  int ch;
  char name[LEN];
  int count = 0;

  // 效验参数
  if (argc < 2) {
    fprintf(stderr, "Usage %s filename\n", *argv);
    exit(EXIT_FAILURE);
  }

  // 设置输入
  if ((in = fopen(*(argv + 1), "r")) == NULL) {
    fprintf(stderr, "I couldn't open the file %s \n", *(argv + 1));
    exit(EXIT_FAILURE);
  }

  // 设置输出
  // 拷贝字符串,把第二个参数 拼接到name上,长度-5为后缀名留空间.注意\0结束符
  strncpy(name, *(argv + 1), LEN - 5);
  // 为文件添加后缀名
  strcat(name, ".red");
  // 以write方式打开文件
  if ((out = fopen(name, "w")) == NULL) {
    fprintf(stderr, "Cant't create output file\n");
    exit(3);
  }
  while ((ch = getc(in)) != EOF) {
    if (count++ % 3 == 0) {
      putc(ch, out);
    }
  }
  if (fclose(in) != 0 || fclose(out) != 0) {
    fprintf(stderr, "Error in closing files\n");
  }
  return 0;
}
```
单词本,区分scanf fscanf,printf,fprintf ,带f的需要传指针
```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 41
int main() {

  FILE *p;
  char words[MAX];

  if ((p = fopen("wordbook", "a+")) == NULL) {
    fprintf(stdout, "OH NO YOU CANT CREATE THE FILE");
    exit(EXIT_FAILURE);
  }

  puts("Enter a word to add to the file;press the \"#\"");
  // fscanf 标准输入,从键盘读取,所以不需要参数啥的
  while ((fscanf(stdin, "%40s", words)) == 1 && *words != '#') {
    // 标准输出,把
    fprintf(p, "%s\n", words);
  }

  puts("File contents:\n");
  // 返回到文件开始处
  // p指向了文件头,所以打印出来是所有的
  rewind(p);
  while (fscanf(p, "%s", words) == 1)
    puts(words);
  puts("DONE");
  if(fclose(p)!=0){
    fprintf(stderr,"CANT CLOSE");
  }
}
```
倒序输出,主要函数fseek(),ftell()
```
#include <stdio.h>
#include <stdlib.h>
#define CNTL_Z EOF
#define SLEN 40

int main(void) {
  char file[SLEN];
  char ch;
  FILE *fp;

  long count, last;

  puts("Enter the name of the file to be processed:");
  scanf("%80s", file);
  if ((fp = fopen(file, "rb")) == NULL) {
    fprintf(stderr, "Error the file is NULL");
    exit(EXIT_FAILURE);
  }

  // 定位到文件结尾
  fseek(fp, 0L, SEEK_END);
  // 获取指针位置
  last = ftell(fp);

  for (count = 1L; count <= last; count++) {
    // 回退,count为偏移量,SEEK_END - count 的位置
    fseek(fp, -count, SEEK_END);
    ch = getc(fp);
    if (ch != EOF) {
      putchar(ch);
    }
  }
  putchar('\n');
  fclose(fp);
}
```
SEEK_SET 文件开始处
SEEK_CUR 当前位置
SEEK_END 文件末尾

其他函数


```c
// 把c指定的字符放回输入流中,如果把字符串放回输入流,下一次读取的时候顺序是相反的
int ungetc(int c, FILE *fp);
// 输出缓冲区所有的为写入数据发送到fp指定的输出文件
int fflush(FILE *fp);
//创建缓冲区存储流,fp:待处理的流,buf缓冲区,size:数组大小,mode:_IOFBF完全缓冲,IOLBF行缓冲,_IONBF无缓冲,操作成功返回0
int setvbuf(FILE *fp,char * restrict buf,int mode,size_t size);
```


```c
// 处理文本信息,如果处理double类型数据,则会损失精度
fprintf()
// fread fwrite 用来处理二进制形式数据
// 把二进制数据写入文件,ptr:待写入数据块的地址,size为数据块儿大小,nmemb:待写入数据块儿的数量,fp:要写入的文件
size_t fwrite(const void * restrict ptr,size_t size,size_t nmemb,FILE * restrict fp);
// 保存一个大小为256字节的数据对象
char buffer[256];
fwrite(buffer,256,1,fp);
//保存一个内含10个double类型的数据
double earnings[10];
fwrite(earnings,sizeof(double),10,fp);
//fread
size_t fread(void * restrict ptr,size_t size,size_t nememb,FILE * restrict fp);
//恢复上述保存数据,这里fp是output不input
double earnings[10];
fread(earnings,sizeof(double),10,fp);
```

```c
/*append.c把文件附加到另一个文件结尾*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define BUFSIZE 4096
#define SLEN 81
void appedn(FILE * source,FILE * dest);
char * s_gets(char *st,int n);

int main(void)
{
  // fa 指向目标文件,fs指向源文件
  FILE *fa,*fs;
  // 附加的文件数量
  int files = 0;
}
```

