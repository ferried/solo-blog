title: K8S-Controller-Manager启动脚本
date: '2020-03-23 14:16:20'
updated: '2020-03-23 14:16:20'
tags: [k8s]
permalink: /articles/2020/03/23/1584944180518.html
---
![](https://img.hacpai.com/bing/20191119.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```bash
#!/bin/bash
// 错误是否输出
/opt/kubernetes/server/bin/kube-controller-manager --logtostderr false
// 日志级别
--v 2
// log目录
--log-dir /opt/kubernetes/logs
// 多个APIServer自动选择一个调度
--leader-elect true
// 指定APIServer的API地址
--master 127.0.0.1:8080
// 服务监听地址
--address 127.0.0.1
// 是否支持网络插件
--allocate-node-cidrs true
// 基于插件分配网段地址
--cluster-cidr 10.244.0.0/16
// 客户端分配地址的范围
--service-cluster-ip-range 10.0.0.0/24
--cluster-signing-cert-file /opt/ssl/k8sca/ca.pem
--cluster-signing-key-file /opt/ssl/k8sca/ca-key.pem
--root-ca-file /opt/ssl/k8sca/ca.pem
--service-account-private-key-file /opt/ssl/k8sca/ca-key.pem
// 证书有效期
--experimental-cluster-signing-duration 87600h0m0s
```