title: deep learning-李宏毅-笔记2
date: '2020-10-07 09:03:53'
updated: '2020-10-07 09:03:53'
tags: [deeplearning]
permalink: /articles/2020/10/07/1602032633860.html
---
<!--
 * @Author: ferried
 * @Email: harlancui@outlook.com
 * @Date: 2020-10-07 08:14:01
 * @LastEditTime: 2020-10-07 08:49:55
 * @LastEditors: ferried
 * @Description: Basic description
 * @FilePath: /jq/HumanLanguageProcessing.md
 * @LICENSE: Apache-2.0
-->

# DeepLearning for human language processing

深度学习于人类语言处理 Text:Speech=5:5

# Natural Language Processing

NLP 自然语言处理 着重在文字 Text:Speech=9:1

# Models

1.Speech Recognition: voice -> model -> word

2.Text To Speech Synthesis: word -> model -> voice

3.voice -> model ->voice

4.speaker recognition, keyword spotting:voice -> model -> class

5.word -> model -> word

6.word -> model -> class
