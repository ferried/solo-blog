title: days
date: '2020-09-24 21:35:28'
updated: '2020-10-07 08:13:05'
tags: [生活]
permalink: /articles/2020/09/24/1600954527988.html
---
![](https://b3logfile.com/bing/20181121.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# day1

罪恶感轻了很多，希望今天可以睡一个好觉~

明天依然美好，加油呀

# day2

> Give me your hand I really need your help

> It's not a game

> What are you saying

> Trembling in the dark

> It's time to find the answer

> A life for counter by the storm

> The waves are all of the world

> Have you tired to face your days that you can learn

# day3

跑了10公里理清思绪。自卑加害我良久。是我真的一切都不配吗，不是，只是不敢坚持习惯了退缩，自卑是最好的借口

今天她依然没理我

晚安

# day4

起了大早，早上有点冷，街道有点空
