title: 《C Primer Plus》手记三
date: '2019-12-06 17:37:48'
updated: '2019-12-06 17:38:10'
tags: [C]
permalink: /articles/2019/12/06/1575625068064.html
---
![](https://img.hacpai.com/bing/20180325.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# <a href="https://blog.eiyouhe.com/articles/2019/11/17/1573958676119.html">C Primer Plus手记一</a>
# <a href="https://blog.eiyouhe.com/articles/2019/11/25/1574669159322.html">C Primer Plus手记二</a>

# 13.位操作

```
一个 byte 8位
[] [] [] [] [] [] [] [] 
11111111 = 255
00000000 = 0
所以 单字节 取值范围为 0-255
```
正数的反码和补码都与原码相同。
负数的反码为对该数的原码除符号位外各位取反。
负数的补码为对该数的原码除符号位外各位取反，然后在最后一位加1


