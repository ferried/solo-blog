title: BREW换源
date: '2020-04-26 09:49:47'
updated: '2020-04-26 09:49:47'
tags: [Brew]
permalink: /articles/2020/04/26/1587865787226.html
---
BREW_REPO="https://mirrors.ustc.edu.cn/brew.git"

cd "$(brew --repo)"
git remote set-url origin https://mirrors.ustc.edu.cn/brew.git

cd "$(brew --repo)/Library/Taps/homebrew/homebrew-core"
git remote set-url origin https://mirrors.ustc.edu.cn/homebrew-core.git

cd "$(brew --repo)"/Library/Taps/homebrew/homebrew-cask
git remote set-url origin https://mirrors.ustc.edu.cn/homebrew-cask.git

brew update