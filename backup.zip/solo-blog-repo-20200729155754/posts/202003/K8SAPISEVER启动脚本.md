title: K8S-API-SEVER 启动脚本
date: '2020-03-23 10:58:25'
updated: '2020-03-31 11:46:36'
tags: [k8s]
permalink: /articles/2020/03/23/1584932305152.html
---
```
#!/bin/bash
/opt/kubernetes/server/bin/kube-apiserver 
# 是否打印错误信息
--logtostderr false 
# 日志级别
--v 2 
# 日志目录
--log-dir /opt/kubernetes/logs 
# etcd的地址
--etcd-servers https://192.168.111.119:2379,https://192.168.111.99:2379,https://192.168.111.109:2379 
# 本服务，APIServer的地址
--bind-address 192.168.111.119 
# 本服务端口
--secure-port 6443 
# 广播地址
--advertise-address 192.168.111.119 
# 是否 使用超级管理员权限创建容器
--allow-privileged true 
# 启动Service时生成的虚拟网段
--service-cluster-ip-range 10.0.0.0/24
# 开启插件 
--enable-admission-plugins NamespaceLifecycle,LimitRanger,ServiceAccount,ResourceQuota,NodeRestriction 
# 授权模式
--authorization-mode RBAC,Node 
# 实现基于token自动颁发证书
--enable-bootstrap-token-auth true 
# 颁发证书的token
--token-auth-file /opt/kubernetes/cfg/token.csv 
# service端口范围
--service-node-port-range 30000-32767 
--kubelet-client-certificate /opt/ssl/k8sca/etcd.pem 
--kubelet-client-key /opt/ssl/k8sca/etcd-key.pem 
--tls-cert-file /opt/ssl/k8sca/etcd.pem 
--tls-private-key-file /opt/ssl/k8sca/etcd-key.pem 
--client-ca-file /opt/ssl/k8sca/ca.pem 
--service-account-key-file /opt/ssl/k8sca/ca-key.pem 
--etcd-cafile /opt/ssl/k8sca/ca.pem 
--etcd-certfile /opt/ssl/k8sca/etcd.pem 
--etcd-keyfile /opt/ssl/k8sca/etcd-key.pem 
# log的最大限度配置
--audit-log-maxage 30 
--audit-log-maxbackup 3 
--audit-log-maxsize 100 
--audit-log-path /opt/kubernetes/k8s-audit.log

```
