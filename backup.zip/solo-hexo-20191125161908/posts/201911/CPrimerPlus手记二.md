title: 《C Primer Plus》手记二
date: '2019-11-25 16:05:59'
updated: '2019-11-25 16:14:03'
tags: [C]
permalink: /articles/2019/11/25/1574669159322.html
---
![](https://img.hacpai.com/bing/20181222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# <a href="https://blog.eiyouhe.com/articles/2019/11/17/1573958676119.html">手记一</a>

# 11.文件

```c
// 标准文件
// C会自动打开三个文件 standard input 标准输入 standard output 标准输出 standard
// error output 标准错误输出 standard input  通常为键盘 standard output
// 通常为显示器 通常标准输入为程序提供输入 getchar() scanf() 标准输出
// putchar(),puts(),printf()

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  // 读取文件时存储每个字符
  int ch;
  // 文件指针
  FILE *fp;
  // 记录文件行数
  unsigned long count = 0;
  // 效验传入参数
  if (argc == 0) {
    printf("Usage: %s filename\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  // 效验是否有文件,如果没有,指针就指不上
  if ((fp = fopen(argv[1], "r")) == NULL) {
    printf("Can't Open %s \n", *(argv + 1));
  }
  //循环读 char
  while ((ch = getc(fp)) != EOF) {
    // 输出char
    putc(ch, stdout);
    count++;
  }
  // 关闭文件
  fclose(fp);
  printf("File %s has %lu characters \n", *(argv + 1), count);
  return 0;
}

// 打开方式 fopen 第二个参数
// r 读模式打开
// w 写模式打开,文件不存在则创建一个新的文件
// a 写模式打开,把现有的文件长度截为0,不存在则创建一个新文件
// r+ 更新模式打开,r+w
// w+ 更新模式打开文件,如果文件存在则将其长度截为0,不存在则新建一个文件
// a+ 更新模式打开文件 可以读整个文件但只能在末尾添加内容
// rb 读模式打开二进制
// wb 写模式打开二进制
// x
// rwax 和 b进行组合
File file1.c has 1533 characters
```
getc() 和 putc()
getc() - getchar()
putc() - putchar()
不同点在于要告诉getc和putc函数使用哪一个文件,

```c
//从标准输入中获取一个字符
ch = getchar();
// 从fp指向的文件中获取一个字符
ch = getc(fp);
// 把ch放入fpout指向的文件中
putc(ch,fpout);
```
指向标准文件的指针
```
标准输入 stdin 键盘
标准输出 stdout 显示器
标准错误 stderr 显示器
```

# BULLDING
