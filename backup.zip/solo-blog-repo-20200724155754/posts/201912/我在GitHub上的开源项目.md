title: 我在 GitHub 上的开源项目
date: '2019-12-04 13:44:53'
updated: '2019-12-04 13:44:53'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [animal-crossing-cli](https://github.com/ferried/animal-crossing-cli) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/ferried/animal-crossing-cli/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/ferried/animal-crossing-cli/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/animal-crossing-cli/network/members "分叉数")</span>

that's a command interface wiki of the animal-crossing



---

### 2. [solo-blog](https://github.com/ferried/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://blog.eiyouhe.com`](https://blog.eiyouhe.com "项目主页")</span>

✍️ 争渡 - ferried's blog 



---

### 3. [my-kubesphere](https://github.com/ferried/my-kubesphere) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ferried/my-kubesphere/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/my-kubesphere/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/my-kubesphere/network/members "分叉数")&nbsp;&nbsp;[🏠`https://github.com/kubesphere/kubesphere`](https://github.com/kubesphere/kubesphere "项目主页")</span>

a simple little demo from kubesphere,more than in ->



---

### 4. [ngx-wechat-qrcode](https://github.com/ferried/ngx-wechat-qrcode) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/ngx-wechat-qrcode/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/ngx-wechat-qrcode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/ngx-wechat-qrcode/network/members "分叉数")</span>

use angular to generate a qrcode for wechat'js



---

### 5. [bom-manager](https://github.com/ferried/bom-manager) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/bom-manager/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/bom-manager/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/bom-manager/network/members "分叉数")</span>

Where dreams begin:manager system of bower that use springboot mybatis and vue.js



---

### 6. [webpack-react-tempalte](https://github.com/ferried/webpack-react-tempalte) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ferried/webpack-react-tempalte/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/webpack-react-tempalte/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/webpack-react-tempalte/network/members "分叉数")</span>

a react&webpack&eslit&babel template



---

### 7. [goSLMM](https://github.com/ferried/goSLMM) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/goSLMM/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/goSLMM/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/goSLMM/network/members "分叉数")</span>

mind map of golang standard library 



---

### 8. [ferried](https://github.com/ferried/ferried) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/ferried/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/ferried/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/ferried/ferried/network/members "分叉数")</span>





---

### 9. [iflytek-voice-text](https://github.com/ferried/iflytek-voice-text) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ferried/iflytek-voice-text/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/iflytek-voice-text/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/iflytek-voice-text/network/members "分叉数")</span>





---

### 10. [clickhouse-fluent-bit](https://github.com/ferried/clickhouse-fluent-bit) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ferried/clickhouse-fluent-bit/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/clickhouse-fluent-bit/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/clickhouse-fluent-bit/network/members "分叉数")</span>

custom plugin of fluent-bit to clickhouse

