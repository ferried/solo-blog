title: Gitlab简易Release脚本
date: '2020-08-30 14:07:36'
updated: '2020-08-30 14:07:36'
tags: [Git]
permalink: /articles/2020/08/30/1598767655948.html
---

```shell
#!/usr/bin/env bash  
  
echo -n "0.请输入你的Github Access Token:"  
read token  
echo -n "1.请输入项目的id:"  
read id  
echo -n "2.请输入项目release的名称:"  
read name  
echo -n "3.请输入即将创建release版本的tag:"  
read tag_name  
echo -n "4.请输入release的描述:"  
read description  
  
curl --header 'Content-Type: application/json' --header "PRIVATE-TOKEN: $token" \  
 --data '{ "name": "'$name'", "tag_name": "'$tag_name'", "ref":"'$tag_name'" ,"description": "'$description'" }' \  
 --request POST http://gitlab_url/api/v4/projects/$id/releases
```



