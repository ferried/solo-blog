title: 关于微前端实现原理与ngx-planet(二)
date: '2021-01-22 14:52:30'
updated: '2021-01-22 16:44:26'
tags: [前端]
permalink: /articles/2021/01/22/1611298349966.html
---
<!--
 * @Author: ferried
 * @Email: harlancui@outlook.com
 * @Date: 2021-01-22 15:02:37
 * @LastEditTime: 2021-01-22 16:04:01
 * @LastEditors: ferried
 * @Description: Basic description
 * @FilePath: /undefined/Users/ferried/ngx-planet2.md
 * @LICENSE: Apache-2.0
-->

<!--
 * @Author: ferried
 * @Email: harlancui@outlook.com
 * @Date: 2021-01-22 15:02:37
 * @LastEditTime: 2021-01-22 16:43:59
 * @LastEditors: ferried
 * @Description: Basic description
 * @FilePath: /undefined/Users/ferried/ngx-planet2.md
 * @LICENSE: Apache-2.0
-->

# 项目结构

```
- packages/planet
|--src
    |--application
        |--planet-application-loader.spec.ts
        |--planet-application-loader.ts # 应用加载器
        |--planet-application-ref.spec.ts
        |--planet-application-ref.ts # 应用的引用
        |--planet-application.service.spec.ts
        |--planet-application.service.ts # 应用逻辑处理Service
        |--portal-application.spec.ts
        |--portal-application.ts  # Portal应用
    |--component
        |--planet-component-loader.spec.ts
        |--planet-component-loader.ts # 组件加载器
        |--planet-component-ref.ts # 组件引用
        |--plant-component.config.ts # 组件配置
    |--empty
        |--empty.component.spec.ts
        |--empty.component.ts   # 空组件
    |--testing
        |--app1.module.ts # 测试用例
        |--app2.module.ts
        |--applications.ts
        |--index.ts
        |--utils.ts
    |--assets-loader.spec.ts
    |--assets-loader.ts    # 静态资源加载器
    |--global-event-dispatcher.spec.ts
    |--global-event-dispatcher.ts   # 全局事件调度器
    |--global-planet.spec.ts
    |--global-planet.ts     # 一些函数
    |--helper.spec.ts
    |--helper.ts    # 一些util函数
    |--module.spec.ts
    |--module.ts    # packager module
    |--planet.class.ts  # 注入配置和InjectToken
    |--planet.spec.ts
    |--planet.ts    # planet 对象，包含了注册，启动设置信息，实质为service
    |--public-api.ts  # 桶
    |--test.ts # 测试
|--karma.config.js  # test config
|--ng-package.json  # packager scheme
|--pakcage.json     # npm
|--tsconfig.lib.json    # compiler config
|--tsconfig.lib.prod.json # env=prod compiler config
|--tsconfig.spec.json   # test copiler config
|--tslint.json  # code lint rules
```

# Portal 的 AppComponent

```ts
    // 首先注入了 planet 对象
    constructor(
        private planet: Planet,
    ) {}
```

```ts
    // 初始化AppComponent中配置Portal和Applications
   ngOnInit() {
       ...
   }
```

```ts
// 设置PlanetApplicationLoader应用加载器的options
this.planet.setOptions({
  // switchMode
  switchMode: SwitchModes.coexist,
  // Application资源加载错误处理回调函数
  errorHandler: (error) => {
    // thy组件库的通知组件，理解成alert吧
    this.thyNotify.error(`错误`, "加载资源失败");
  },
});
```

```ts
// SiwtchModes枚举类，切换子应用的模式，默认切换会销毁，设置 coexist 后只会隐藏
export enum SwitchModes {
  default = "default",
  coexist = "coexist",
}
```

```ts
    // Injectable直接注到模块里了(唯一),项目启动会通过Factory自行创建,所以不需要初始化
    @Injectable({
        providedIn: 'root'
    })
    export class PlanetApplicationLoader {
    private firstLoad = true;

    private startRouteChangeEvent: PlanetRouterEvent;

    // 这里是ApplicationLoader中的option
    private options: PlanetOptions

    ......

    }

```

```ts
// 向planet注册了两个应用
this.planet.registerApps([
  {
    // 子应用名
    name: "app1",
    // 应用渲染的容器元素, 指定子应用显示在哪个元素内部
    hostParent: "#app-host-container",
    // 宿主元素的 Class，也就是在子应用启动组件上追加的样式
    hostClass: appHostClass,
    // 子应用路由路径前缀，根据这个匹配应用
    routerPathPrefix: /\/app1|app4/,
    // 脚本和样式文件路径前缀，多个脚本可以避免重复写同样的前缀
    resourcePathPrefix: "/static/app1/",
    // 是否启用预加载，启动后刷新页面等当前页面的应用渲染完毕后预加载子应用
    preload: settings.app1.preload,
    // 切换子应用的模式，默认切换会销毁，设置 coexist 后只会隐藏
    switchMode: settings.app1.switchMode,
    // 是否串行加载脚本静态资源
    loadSerial: true,
    // 样式前缀
    stylePrefix: "app1",
    // 脚本资源文件
    scripts: ["main.js"],
    // 样式资源文件
    styles: ["styles.css"],
    // 应用程序打包后的脚本和样式文件替换
    manifest: "/static/app1/manifest.json",
    // 附加数据，主要应用于业务，比如图标，子应用的颜色，显示名等个性化配置
    extra: {
      name: "应用1",
      color: "#ffa415",
    },
  },
  .......
]);
```

在看 `planet.registerApps`之前先看一下 `GlobalPlanet`

构建中...
