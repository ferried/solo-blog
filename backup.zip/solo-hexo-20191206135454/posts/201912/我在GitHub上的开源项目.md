title: 我在 GitHub 上的开源项目
date: '2019-12-04 13:44:53'
updated: '2019-12-04 13:44:53'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/ferried/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ferried/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://blog.eiyouhe.com`](https://blog.eiyouhe.com "项目主页")</span>

争渡 - ferried's blog



---

### 2. [ngx-wechat-qrcode](https://github.com/ferried/ngx-wechat-qrcode) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/ngx-wechat-qrcode/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/ngx-wechat-qrcode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/ngx-wechat-qrcode/network/members "分叉数")</span>

use angular to generate a qrcode for wechat'js



---

### 3. [bom-manager](https://github.com/ferried/bom-manager) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/bom-manager/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/bom-manager/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/bom-manager/network/members "分叉数")</span>

manager system of bower that use springboot mybatis and vue.js

