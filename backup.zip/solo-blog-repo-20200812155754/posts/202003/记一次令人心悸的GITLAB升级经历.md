title: 记一次令人心悸的GITLAB升级经历
date: '2020-03-04 20:19:43'
updated: '2020-03-04 20:19:43'
tags: [运维]
permalink: /articles/2020/03/04/1583324383406.html
---
![](https://img.hacpai.com/bing/20190219.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 起因

今天日常连接上 VPN，上 GitLab 私服，对离职人员进行 block，3 个月无更新的项目进行 archive 操作，将新项目分好组，并通知其余负责人。

然后！然后我想到了最近三个月都没有更新 GitLab 了，12.5.1 版本，最新的是 12.8 版本，想着更新一下，然后问题就来了。

# 经过

按照常规操作，https://packages.gitlab.com/gitlab/gitlab-ce,从这个网站 wget 下最新的 GitLab Rpm 包，准备更新。

首先进行了版本查看(由于 GitLab 在数据恢复的时候必须保持版本一致),并记录了当前的 GitLab *全*版本号 `gitlab-ce-12.5.3-ce.0.el7.x86_64`

然后进行了数据备份操作`gitlab-rake gitlab:backup:create`并将备份后的文件本地保留一份到`~`目录下，scp出去一份到自己的服务器上

最后感觉万无一失的开始搞 `yum install -y gitlab-ce-12.8xxxxx`,然后看着日志滚动刷屏，我淡然的感觉应该没什么问题，因为更了不下5个版本了，就出去抽烟了。

等抽烟回来一看，卧槽，`Exception`眉头一皱发现事情不简单了。略慌，然后我打开网址查看，并没有什么问题，当我查看当前Gitlan版本的时候显示:12.5.
心里想，重启一下应该就好了，`gitlab-ctl restart`，然后gitlab页面就502,后面就是500.

![image.png](https://img.hacpai.com/file/2020/03/image-affc7a30.png)

然后我就赶紧通知各个部门经理啥的，着手进行修复工作。

首先尝试 `yum undo`来进行回滚操作，操作失败
然后尝试在重新升级一次`yum install -y xxx` 失败
最后仗着感觉自己备份了，就开始删Gitlab,`gitlab-ctl uninstall`
`rm -rf /opt/gitlab`,`rm -rf /etc/gitlab` `yum remove gitlab-ce`。万幸的是，`gitlab-ctl uninstall`的时候自动把 `/etc/gitlab`下的`gitlab.rb`,`xxx,json`自动备份到了	`~`目录下，以至于最后恢复成功，没有发生惨案

然后我根据记录下的版本号`gitlab-ce-12.5.3-ce.0.el7.x86_64`重新下载了rpm包，重新安装。
安装后必须用 `gitlab-ctl reconfigure`来加载各种配置，启动`redis,nginx,xxx等各种依赖服务`这里遇到了两个问题，注意，重装的时候会遇到这问题的，导致我来来回回删装删装了两个小时妄图安装成功

遇到的问题: redis连接不上，xxx file not found.

第一个解决方式: 
![image.png](https://img.hacpai.com/file/2020/03/image-d5b09750.png)

第二个,xxx file not found
这个我调了好久搜了好久，issue都感觉搜遍了，最后从stackoverFlow找到了解决途径
![image.png](https://img.hacpai.com/file/2020/03/image-f7e417e9.png)
于是呼我就去改了ruby脚本

接下来一切正常，然后安装完了一个新的gitlab也能跑起来了，现在到了恢复的时候,首先，gitlab要在运行中，然后停止以下两个服务

```
 gitlab-ctl stop unicorn
 gitlab-ctl stop sidekq
```
然后我以为 直接去把tar包拖过来运行`` gitlab-rake gitlab:backup:restore BACKUP=xxxxx``就可以恢复了。

然后！！！我慌了！我进去看了，人员/组织/项目都恢复了（我以为项目恢复了，结果只恢复了名称）
![image.png](https://img.hacpai.com/file/2020/03/image-ae424ad6.png)

看到了吗 No repository,我真的慌了。心想，完了，这他妈可能是备份的不好使。

最后研究出了结果,我找到了在第一次运行`gitlab-ctl uninstall`时在`~`目录下留下的一堆文件，把他们盖到了`/etc/gitlab`下，然后又进行了一次恢复。

# 结果

最后我手冰凉，腿都软了，发誓以后这个服务器我绝对再也不登陆了。再也不更新了。爱咋咋地吧。好在一切都恢复好了。淦。这是我从业3年以来经历过最最最最最最最最最最最最凶险的4个小时。卧槽。。。心有余悸。

# 总结

记录 gitlab 版本，备份数据文件，备份/etc/gitlab，备份/opt/gitlab。
如果支持快照，那必须搞个快照。在操作之前，最好新起一个环境，模拟这次操作，如果有问题，那么恭喜你，还好你没直接在正式环境搞。如果没问题，多试两次。如果到正式环境上出现了问题，不要慌，先打报告，让别人心里有数，然后自己努力的去解决。解决不掉有快照的话，万事大吉。

# 祝愿

祝愿各位职业生涯内不会遇到我这种问题。


