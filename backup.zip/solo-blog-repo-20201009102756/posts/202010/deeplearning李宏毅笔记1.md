title: deep learning-李宏毅-笔记1
date: '2020-10-06 17:27:58'
updated: '2020-10-06 17:27:58'
tags: [deeplearning]
permalink: /articles/2020/10/06/1601976478210.html
---
# 咕噜咕噜咕噜咕噜咕噜~~~

# Supervised Learning

## Regression Classification

input => f(x) => number

## Binary Classification

input => f(x) => yes ? or no?

## Multi-class Classification

input => f(x) => a?b?c?d?e?f?g?h?j....?

## Genertation

input => f(x) = pic,word,anything

## Supervised Learning

期待输入一张猫的图片输出猫 Cat Picture => f(x) => "Cat"

那么需要训练, 告诉机器什么是猫什么是狗 也就是为数据打标注 -> `Labeled Data`

当f(x)经过Labeled Cat训练后 Cat Labeled Data => f(x) => Cat  那么f(x)就是训练出的结果

## Loss

评估 f(x) 是否精确的指标

例如 x-cat,x-cat,x-dog,x-dog => f(x) => dog,dog,dog,dog  那么 Loss=50%

## Reinforcement Learning & Supervised Learning

Supervised Learning: 比如围棋，你需要演算接下来每一步发生的情况丢入 => f(x) => result

Reinforcement Learning: First Mov => Many Moves => Win!!! 机器自己想办法提高正确率

Reward = Win or Lose 是引导机器学习的方向，指标

AlphaGo Beta is supervised learning + reinforcement learning
AlphaGo Zero is reinforcement learning

## Unsupervised Learning

No Labeled Data 看机器自己学到什么

# 如何寻找fx

## 确定fx搜寻范围

1.Linear

2.NetWork Architecture -> RNN,CNN

# Explainable AI

机器可以辨识图片里有一只猫，但是为什么他会觉得图片里有一只猫呢

# Adversarial Attack

影响辨识非常强健，恶意攻击影像辨识 把猫辨识成鱼

# Network Comprrssion

缩小体积可移植

# Anomaly Detection

机器: 我知道我不知道

# Meta Learning

learning to learning

# Life-Long learning,Continuous Learning,Never Ending Learning,Incremental Learning

keeping learning
