title: GO语言程序设计
date: '2019-09-05 10:47:03'
updated: '2019-09-05 10:47:19'
tags: [Go]
permalink: /articles/2019/09/05/1567651623206.html
---
# 1.五个例子

Go语言的官方编译器被称为gc，包括编译工具5g、6g和8g，链接工具5l、6l和8l，以及文档查看工具godoc（在Windows下分别是5g.exe、6l.exe等）

- godoc http=:8000 本地查文档
- godoc imageNewRGBA 终端查文档
- godoc image/png 查包文档

## HelloWho

```go
package main

//导包
import (
	"fmt"
	"os"
	"strings"
)

func main() {
	who := "World";
	//如果传入参数长度大于1
	if len(os.Args) > 1 {
		// 命令行所有参数拼接以后传给who
		who = strings.Join(os.Args[1:], "")
	}
	// 打印
	fmt.Println("Hello", who)
}

```





