title: SpringBoot
date: '2019-08-19 09:37:41'
updated: '2019-08-19 09:37:41'
tags: [Spring, Java]
permalink: /articles/2019/08/19/1566178661370.html
---
![](https://img.hacpai.com/bing/20180215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Framework基础

## IOC(DI)

依赖注入,控制反转:bean本身通过使用类的直接构造控制其依赖关系的实例化  
org.springframework.beans 和 org.springframework.context包是IOC容器的基础  
BeanFactory 提供了一种能管理任何类型的类的高级管理机制  
ApplicationContext 是 BeanFactory 的子接口   
更容易与Spring的AOP功能集成  
国际化资源处理  

### 容器总览

org.springframework.context.ApplicationContext接口表示Spring IoC容器，负责实例化，配置和组装bean。  
ApplicationContext接口提供了几种实现,在独立的应用中会创建一个ClassPathXmlApplicationContext或者FileSystemXmlApplicationContext
,这些类来配置元数据从而实例化bean  

1.基于注释配置  
2.基于java配置   
3.基于xml配置   

```
以下是基于xml配置bean
这些bean定义对应于构成应用程序的实际对象。通常，您定义服务层对象，数据访问对象（DAO），表示对象（如Struts Action实例），基础结构对象（如Hibernate SessionFactories，JMS Queues等）。
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd">
        // id 为标识单个bean的字符串 class为全类名
    <bean id="..." class="...">   
        <!-- collaborators and configuration for this bean go here -->
    </bean>
    <bean id="..." class="...">
        <!-- collaborators and configuration for this bean go here -->
    </bean>
    <!-- more bean definitions go here -->
</beans>
```

实例化容器

```
ApplicationContext ctx = new ClassPathXmlApplicationContext("xxx.xml","xxy.xml")
```

```
// service的bean的配置
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!-- services -->
    <bean id="petStore" class="org.springframework.samples.jpetstore.services.PetStoreServiceImpl">
        // 另一个beande 名称和引用
        <property name="accountDao" ref="accountDao"/>
        // 同上
        <property name="itemDao" ref="itemDao"/>
        <!-- additional collaborators and configuration for this bean go here -->
    </bean>

    <bean id="accountDao"
        class="org.springframework.samples.jpetstore.dao.jpa.JpaAccountDao">
        <!-- additional collaborators and configuration for this bean go here -->
    </bean>

    <bean id="itemDao" class="org.springframework.samples.jpetstore.dao.jpa.JpaItemDao">
        <!-- additional collaborators and configuration for this bean go here -->
    </bean>


    <!-- more bean definitions for services go here -->

</beans>
```

使用容器

```
// create and configure beans
// 通过配置文件创建一个容器
ApplicationContext context = new ClassPathXmlApplicationContext("services.xml", "daos.xml");

// retrieve configured instance
// 通过容器和标识和类型获取一个bean
PetStoreService service = context.getBean("petStore", PetStoreService.class);

// use configured instance
使用容器中的bean
List<String> userList = service.getUsernameList();
```

### bean预览

每个bean都有一个或者多个标识符,可以指定id或者name  
标识符映射bean所以标识符应该是唯一的  
通过类路径扫描,Spring按照描述的规则为未命名component生成bean名称时采用驼峰命名规范  

在xml中可以为bean取别名

```
<alias name="formName" alias="toName"/>
```


```
// method返回bean
<bean id="clientService"
    class="examples.ClientService"
    factory-method="createInstance"/>

public class ClientService {
    private static ClientService clientService = new ClientService();
    private ClientService() {}
    // xml 中定义的构造方法
    public static ClientService createInstance() {
        return clientService;
    }
}
```

```
// 工厂方法返回bean
// 工厂
<bean id="serviceLocator" class="examples.DefaultServiceLocator">
    <!-- inject any dependencies required by this locator bean -->
</bean>

// 使用工厂方法创建bean
<bean id="clientService"
    factory-bean="serviceLocator"
    factory-method="createClientServiceInstance"/>
```

### 依赖


#### 注入方式

```
// 构造参数注入

package x.y;

public class ThingOne {

    public ThingOne(ThingTwo thingTwo, ThingThree thingThree) {
        // ...
    }
}

<beans>
    <bean id="thingOne" class="x.y.ThingOne">
        <constructor-arg ref="thingTwo"/>
        <constructor-arg ref="thingThree"/>
    </bean>

    <bean id="thingTwo" class="x.y.ThingTwo"/>

    <bean id="thingThree" class="x.y.ThingThree"/>
</beans>
```


```
package examples;

public class ExampleBean {

    // Number of years to calculate the Ultimate Answer
    private int years;

    // The Answer to Life, the Universe, and Everything
    private String ultimateAnswer;

    public ExampleBean(int years, String ultimateAnswer) {
        this.years = years;
        this.ultimateAnswer = ultimateAnswer;
    }
}

// 类型注入
<bean id="exampleBean" class="examples.ExampleBean">
    <constructor-arg type="int" value="7500000"/>
    <constructor-arg type="java.lang.String" value="42"/>
</bean>
// 索引注入
<bean id="exampleBean" class="examples.ExampleBean">
    <constructor-arg index="0" value="7500000"/>
    <constructor-arg index="1" value="42"/>
</bean>

// 名称注入
package examples;

public class ExampleBean {

    // Fields omitted

    @ConstructorProperties({"years", "ultimateAnswer"})
    public ExampleBean(int years, String ultimateAnswer) {
        this.years = years;
        this.ultimateAnswer = ultimateAnswer;
    }
}

<bean id="exampleBean" class="examples.ExampleBean">
    <constructor-arg name="years" value="7500000"/>
    <constructor-arg name="ultimateAnswer" value="42"/>
</bean>

// setter注入
public class SimpleMovieLister {

    // the SimpleMovieLister has a dependency on the MovieFinder
    private MovieFinder movieFinder;

    // a setter method so that the Spring container can inject a MovieFinder
    public void setMovieFinder(MovieFinder movieFinder) {
        this.movieFinder = movieFinder;
    }

    // business logic that actually uses the injected MovieFinder is omitted...
}

<bean id="exampleBean" class="examples.ExampleBean">
    <!-- setter injection using the nested ref element -->
    <property name="beanOne">
        <ref bean="anotherExampleBean"/>
    </property>

    <!-- setter injection using the neater ref attribute -->
    <property name="beanTwo" ref="yetAnotherBean"/>
    <property name="integerProperty" value="1"/>
</bean>

<bean id="anotherExampleBean" class="examples.AnotherBean"/>
<bean id="yetAnotherBean" class="examples.YetAnotherBean"/>

```

#### 配置细细节

##### 直接使用值

```
<bean id="myDataSource" class="org.apache.commons.dbcp.BasicDataSource" destroy-method="close">
    <!-- results in a setDriverClassName(String) call -->
    <property name="driverClassName" value="com.mysql.jdbc.Driver"/>
    <property name="url" value="jdbc:mysql://localhost:3306/mydb"/>
    <property name="username" value="root"/>
    <property name="password" value="masterkaoli"/>
</bean>

使用p命名空间

<beans xmlns="http://www.springframework.org/schema/beans"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:p="http://www.springframework.org/schema/p"
    xsi:schemaLocation="http://www.springframework.org/schema/beans
    http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="myDataSource" class="org.apache.commons.dbcp.BasicDataSource"
        destroy-method="close"
        p:driverClassName="com.mysql.jdbc.Driver"
        p:url="jdbc:mysql://localhost:3306/mydb"
        p:username="root"
        p:password="masterkaoli"/>

</beans>
```

##### idref

```
<bean id="theTargetBean" class="..."/>

<bean id="theClientBean" class="...">
    <property name="targetName">
        <idref bean="theTargetBean"/>
    </property>
</bean>
```

##### 内部类

```
<bean id="outer" class="...">
    <!-- instead of using a reference to a target bean, simply define the target bean inline -->
    <property name="target">
        <bean class="com.example.Person"> <!-- this is the inner bean -->
            <property name="name" value="Fiona Apple"/>
            <property name="age" value="25"/>
        </bean>
    </property>
</bean>
```

##### 集合

```
<bean id="moreComplexObject" class="example.ComplexObject">
    <!-- results in a setAdminEmails(java.util.Properties) call -->
    <property name="adminEmails">
        <props>
            <prop key="administrator">administrator@example.org</prop>
            <prop key="support">support@example.org</prop>
            <prop key="development">development@example.org</prop>
        </props>
    </property>
    <!-- results in a setSomeList(java.util.List) call -->
    <property name="someList">
        <list>
            <value>a list element followed by a reference</value>
            <ref bean="myDataSource" />
        </list>
    </property>
    <!-- results in a setSomeMap(java.util.Map) call -->
    <property name="someMap">
        <map>
            <entry key="an entry" value="just some string"/>
            <entry key ="a ref" value-ref="myDataSource"/>
        </map>
    </property>
    <!-- results in a setSomeSet(java.util.Set) call -->
    <property name="someSet">
        <set>
            <value>just some string</value>
            <ref bean="myDataSource" />
        </set>
    </property>
</bean>
```

##### 复合属性

```
<bean id="beanOne" class="ExampleBean" depends-on="manager"/>
<bean id="manager" class="ManagerBean" />

----
<bean id="beanOne" class="ExampleBean" depends-on="manager,accountDao">
    <property name="manager" ref="manager" />
</bean>
<bean id="manager" class="ManagerBean" />
<bean id="accountDao" class="x.y.jdbc.JdbcAccountDao" />
```

##### 懒加载

```
<beans default-lazy-init="true">
    <!-- no beans will be pre-instantiated... -->
</beans>
```

##### 自动装配模式

no:无自动装配
byName:按属性名自动装配
byType:按类型自动装配
constructor:按类型构造自动装配

##### 方法注入Context

```
// a class that uses a stateful Command-style class to perform some processing
package fiona.apple;

// Spring-API imports
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class CommandManager implements ApplicationContextAware {

    private ApplicationContext applicationContext;

    public Object process(Map commandState) {
        // grab a new instance of the appropriate Command
        Command command = createCommand();
        // set the state on the (hopefully brand new) Command instance
        command.setState(commandState);
        return command.execute();
    }

    protected Command createCommand() {
        // notice the Spring API dependency!
        //使用applicationContext通过name和class获取一个bean
        return this.applicationContext.getBean("command", Command.class);
    }
    // 因为实现了ContextAware接口,实现接口函数
    public void setApplicationContext(
            ApplicationContext applicationContext) throws BeansException {
        // 将application设置到类中
        this.applicationContext = applicationContext;
    }
}
```

##### 方法替换

```
public class MyValueCalculator {

    public String computeValue(String input) {
        // some real code...
    }

    // some other methods...
}

/**
 * meant to be used to override the existing computeValue(String)
 * implementation in MyValueCalculator
 */
public class ReplacementComputeValue implements MethodReplacer {

    public Object reimplement(Object o, Method m, Object[] args) throws Throwable {
        // get the input value, work with it, and return a computed result
        String input = (String) args[0];
        ...
        return ...;
    }
}
```

```
<bean id="myValueCalculator" class="x.y.z.MyValueCalculator">
    <!-- arbitrary method replacement -->
    // 替换函数
    <replaced-method name="computeValue" replacer="replacementComputeValue">
        <arg-type>String</arg-type>
    </replaced-method>
</bean>

<bean id="replacementComputeValue" class="a.b.c.ReplacementComputeValue"/>
```

### Bean范围

```
<bean id="" class="" scope="request">
```

#### singleton
将单个bean定义范围限定为每个Spring IoC容器的单个对象实例。
整个应用中每次getbean都得到同一个

#### prototype
将单个bean定义范围限定为任意数量的对象实例。
getBean获取新new的实例

#### request
将单个bean定义范围限定为单个HTTP请求的生命周期。
每个HTTP请求使用bean定义来创建bean 的新实例。每个请求getBean都会new一个,请求走以后将会丢弃bean。

#### session
将单个bean定义范围限定为HTTP会话的生命周期。
同一session环境下，不管你从bean容器中获取对应bean定义的实例多少次，你取到的总是一个相同的实例。

#### application
将单个bean定义范围限定为ServletContext的生命周期。
当定义一个bean的scope为application时表示对应的bean实例是跟ServletContext绑定在一起的，即在整个ServletContext环境下都只会拥有一个对应的实例。

### 定制bean

实现Spring InitializingBean和DisposableBean接口,

```
 @Override
    // bean 初始化
    public void afterPropertiesSet() throws Exception {
        System.out.println("one");
    }

    @Override
    // bean 销毁
    public void destroy() throws Exception {
        System.out.println("two");
    }
```

```
public class DefaultBlogService implements BlogService {
    private BlogDao blogDao;
    public void setBlogDao(BlogDao blogDao) {
        this.blogDao = blogDao;
    }
    // this is (unsurprisingly) the initialization callback method
    // 自定义初始化方法
    public void init() {
        if (this.blogDao == null) {
            throw new IllegalStateException("The [blogDao] property must be set.");
        }
    }
}

// 配置默认初始化函数init
<beans default-init-method="init">
    <bean id="blogService" class="com.something.DefaultBlogService">
        <property name="blogDao" ref="blogDao" />
    </bean>
</beans>
```

```
实现Lifecycle接口

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }

    @Override
    public boolean isRunning() {
        return false;
    }

实现LifecycleProcessor接口

    @Override
    // 刷新上下文
    public void onRefresh() {

    }

    @Override
    public void onClose() {

    }
```

```
public class Test implements ApplicationContextAware, BeanNameAware {
    @Override
    // ApplicationContextAware 提供applicationContext对象
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    }
    // BeanNameAware提供为bean设置名称的方法
    @Override
    public void setBeanName(String name) {

    }
}
```

### Bean继承

```
<bean id="inheritedTestBean" abstract="true"
        class="org.springframework.beans.TestBean">
    <property name="name" value="parent"/>
    <property name="age" value="1"/>
</bean>

<bean id="inheritsWithDifferentClass"
        class="org.springframework.beans.DerivedTestBean"
        // parent 指向上一个id
        parent="inheritedTestBean" init-method="initialize">  
    <property name="name" value="override"/>
    <!-- the age property value of 1 will be inherited from parent -->
</bean>
```

### 扩建

```
public class InstantiationTracingBeanPostProcessor implements BeanPostProcessor {

    // simply return the instantiated bean as-is
    public Object postProcessBeforeInitialization(Object bean, String beanName) {
        return bean; // we could potentially return any object reference here...
    }

    // 后置处理
    public Object postProcessAfterInitialization(Object bean, String beanName) {
        System.out.println("Bean '" + beanName + "' created : " + bean.toString());
        return bean;
    }
}
```

### 基于注释的配置

```
@Bean 返回Bean
@Autowired 自动注入
@Component 组件
@Primary 标识子类,优先注入
@Qualifier 为每一个bean起别名,并通过别名注入bean
@Configuration 配置类
@Resource 按照名称装配bean
@PostConstruct  被@PostConstruct修饰的方法会在服务器加载Servlet的时候运行，并且只会被服务器调用一次，类似于Serclet的inti()方法。被@PostConstruct修饰的方法会在构造函数之后，init()方法之前运行。
@PreDestroy  被@PreDestroy修饰的方法会在服务器卸载Servlet的时候运行，并且只会被服务器调用一次，类似于Servlet的destroy()方法。被@PreDestroy修饰的方法会在destroy()方法之后运行，在Servlet被彻底卸载之前。
@Import 将class显示加入到IOC容器中
@Service dao实现类
@Repository dao
@SessionScope 前面讲到bean的四个范围

```

### AOP

```
@Component
// 切面
@Aspect
public class Operator {
    
    // 切入点
    @Pointcut("execution(* com.aijava.springcode.service..*.*(..))")
    public void pointCut(){}
    
    // 之前
    @Before("pointCut()")
    public void doBefore(JoinPoint joinPoint){
        System.out.println("AOP Before Advice...");
    }
    
    // 之后
    @After("pointCut()")
    public void doAfter(JoinPoint joinPoint){
        System.out.println("AOP After Advice...");
    }
    
    // return
    @AfterReturning(pointcut="pointCut()",returning="returnVal")
    public void afterReturn(JoinPoint joinPoint,Object returnVal){
        System.out.println("AOP AfterReturning Advice:" + returnVal);
    }
    
    // 异常
    @AfterThrowing(pointcut="pointCut()",throwing="error")
    public void afterThrowing(JoinPoint joinPoint,Throwable error){
        System.out.println("AOP AfterThrowing Advice..." + error);
        System.out.println("AfterThrowing...");
    }
    
    // 环绕
    @Around("pointCut()")
    public void around(ProceedingJoinPoint pjp){
        System.out.println("AOP Aronud before...");
        try {
            pjp.proceed();
        } catch (Throwable e) {
            e.printStackTrace();
        }
        System.out.println("AOP Aronud after...");
    }
    
}
```

# SpringMvc

装饰器和知识点

```
@Controller 控制器
@GetMapping action path
@PostMapping
@PutMapping
@DeleteMapping
@PatchMapping
@PostMapping(path = "/pets", consumes = "application/json") content-type=application/json
@GetMapping(path = "/pets/{petId}", produces = "application/json;charset=UTF-8") 
@RequestParam 获取form参数
@RequestHeader 获取key对应的header value
@CookieValue("JSESSIONID") 获取cookie
@ModelAttribute 几个域对象
@SessionAttributes
@SessionAttribute
@RequestAttribute
return "redirect:files/{path}";  重定向
@RequestBody 解析json
HttpEntity<Account> entity 解析json
@ResponseBody 序列化到response
@InitBinder 数据转换
@ExceptionHandler 处理异常
@CrossOrigin 跨域

```

```
跨域
@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {

        registry.addMapping("/api/**")
            .allowedOrigins("http://domain2.com")
            .allowedMethods("PUT", "DELETE")
            .allowedHeaders("header1", "header2", "header3")
            .exposedHeaders("header1", "header2")
            .allowCredentials(true).maxAge(3600);

        // Add more mappings...
    }
}

跨域过滤器
CorsConfiguration config = new CorsConfiguration();

// Possibly...
// config.applyPermitDefaultValues()

config.setAllowCredentials(true);
config.addAllowedOrigin("http://domain1.com");
config.addAllowedHeader("*");
config.addAllowedMethod("*");

UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
source.registerCorsConfiguration("/**", config);

CorsFilter filter = new CorsFilter(source);
```

```
缓存

// Cache for an hour - "Cache-Control: max-age=3600"
CacheControl ccCacheOneHour = CacheControl.maxAge(1, TimeUnit.HOURS);

// Prevent caching - "Cache-Control: no-store"
CacheControl ccNoStore = CacheControl.noStore();

// Cache for ten days in public and private caches,
// public caches should not transform the response
// "Cache-Control: max-age=864000, public, no-transform"
CacheControl ccCustom = CacheControl.maxAge(10, TimeUnit.DAYS).noTransform().cachePublic();


@GetMapping("/book/{id}")
public ResponseEntity<Book> showBook(@PathVariable Long id) {

    Book book = findBook(id);
    String version = book.getVersion();

    return ResponseEntity
            .ok()
            .cacheControl(CacheControl.maxAge(30, TimeUnit.DAYS))
            .eTag(version) // lastModified is also available
            .body(book);
}
```

## WebSocket

```
```

## STOMP

```
```

# Springboot

## gradle配置

Springboot 使用gradle创建,gradle入门参照<a href="https://ferried.github.io/blog/2018-06/gradle/">gradle</a>
详细配置参照
<a href="https://docs.spring.io/spring-boot/docs/2.2.0.BUILD-SNAPSHOT/gradle-plugin/reference/html/#packaging-executable-jars">gradle build springboot</a>
本项目地址<a href="https://github.com/ferried/gradle-boot">gradle-boot</a>

```
buildscript {
    ext {
        springBootVersion = '2.1.1.RELEASE'
    }
    repositories {
        mavenCentral()
    }
    dependencies {
        classpath("org.springframework.boot:spring-boot-gradle-plugin:${springBootVersion}")
    }
}

configurations {
    providedRuntime
    # 热部署相关
    developmentOnly
    runtimeClasspath {
        extendsFrom developmentOnly
    }
}


apply plugin: 'java'
apply plugin: 'eclipse'
apply plugin: 'org.springframework.boot'
apply plugin: 'io.spring.dependency-management'

group = 'io.github.ferried'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = 1.8

repositories {
    mavenCentral()
}


dependencies {
    implementation('org.springframework.boot:spring-boot-starter-web')
    # jpa依赖可以注释
    implementation('org.springframework.boot:spring-boot-starter-data-jpa')
    # 同上
    compile('mysql:mysql-connector-java:5.1.28')
    # 开发环境工具(热部署)
    developmentOnly("org.springframework.boot:spring-boot-devtools")
    testImplementation('org.springframework.boot:spring-boot-starter-test')
}
```

## yml

先将配置贴上，后面一一解释

```
spring:
  datasource:
    url: jdbc:mysql://192.168.1.1:3306/spring_stu
    username: root
    password: 111111
    driver-class-name: com.mysql.jdbc.Driver
  jpa:
    database: MYSQL
    show-sql: true
    hibernate:
      ddl-auto: update
  output:
    ansi:
      enabled: always
  config:
    name: application
  banner:
    location: asdf.txt
  devtools:
    add-properties: true
    restart:
      log-condition-evaluation-delta: false
      exclude: templates/**
      additional-paths: static/**,public/**
      enabled: false
    remote:
      secret: my-secret
    livereload:
      enabled: true
      port: 35729
  http:
    log-request-details: true
logging:
  level:
    root: info
    hibernate: debug
    tomcat: info
    web: debug
  file:
    max-size: 10MB
  path: /Users/ferried/Projects/gradle-boot/src/main/resources/asdf.log
  group:
    tomcat: org.apache.catalina, org.apache.coyote, org.apache.tomcat
```

## 默认包

```
COM
 +  - 例子
     +  - 我的应用程序
         +  -  Application.java 注意,Application这里放到了所有包的父目录
         |
         +  - 客户
         | +  -  Customer.java
         | +  -  CustomerController.java
         | +  -  CustomerService.java
         | +  -  CustomerRepository.java
         |
         +  - 订单
             +  -  Order.java
             +  -  OrderController.java
             +  -  OrderService.java
             +  -  OrderRepository.java
```

## Application

### 启动横幅

yml中
```
// 开关横幅显示
spring:
    main:
        banner-mode: "off"
//指定横幅文件
 banner:
    location: asdf.txt
    
// 在代码中设置
public static void main(String[] args) {
    SpringApplication app = new SpringApplication(MySpringConfiguration.class);
    app.setBannerMode(Banner.Mode.OFF);
    app.run(args);
}

```

```
asdf.txt写入以下内容来替换Springboot默认横幅

////////////////////////////////////////////////////////////////////
//							_ooOoo_								  //
//						   o8888888o							  //	
//						   88" . "88							  //	
//						   (| ^_^ |)							  //	
//						   O\  =  /O							  //
//						____/`---'\____							  //						
//					  .'  \\|     |//  `.						  //
//					 /  \\|||  :  |||//  \						  //	
//				    /  _||||| -:- |||||-  \						  //
//				    |   | \\\  -  /// |   |						  //
//					| \_|  ''\---/''  |   |						  //		
//					\  .-\__  `-`  ___/-. /						  //		
//				  ___`. .'  /--.--\  `. . ___					  //	
//				."" '<  `.___\_<|>_/___.'  >'"".				  //
//			  | | :  `- \`.;`\ _ /`;.`/ - ` : | |				  //	
//			  \  \ `-.   \_ __\ /__ _/   .-` /  /                 //
//		========`-.____`-.___\_____/___.-`____.-'========		  //	
//				             `=---='                              //
//		^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^        //
//         佛祖保佑       永无BUG		永不修改		spring:2.20		  //
////////////////////////////////////////////////////////////////////
版本号:${application.version}
格式化的版本号:${application.formatted-version}
${spring-boot.version}
${spring-boot.formatted-version}
${Ansi.NAME}
${application.title}
```

其中
```
${application.version}您声明的应用程序的版本号MANIFEST.MF。例如， Implementation-Version: 1.0打印为1.0。
${application.formatted-version}应用程序的版本号，在声明中MANIFEST.MF显示并格式化以显示（用括号括起来并带有前缀v）。例如(v1.0)。
${spring-boot.version}您正在使用的Spring Boot版本。例如2.2.0.BUILD-SNAPSHOT。
${spring-boot.formatted-version}您正在使用的Spring Boot版本，格式化显示（用括号括起来并带有前缀v）。例如(v2.2.0.BUILD-SNAPSHOT)。
${application.title}申请的标题，如中所述MANIFEST.MF。例如 Implementation-Title: MyApp打印为MyApp。
```

### 自定义Application

```
# 使用SpringApplicationBuilder构建应用程序

new SpringApplicationBuilder()
        .sources(Parent.class)
        .child(Application.class)
        .bannerMode(Banner.Mode.OFF)
        .run(args);
```

### 程序监听器

```
查看传参类型并实现接口重写方法传入即可
SpringApplication.addListeners(​)方法
SpringApplicationBuilder.listeners()方法注册 
```

```
应用程序运行时，应按以下顺序发送应用程序事件：
ApplicationStartingEvent:在运行开始时但在进行任何处理之前发送
ApplicationEnvironmentPreparedEvent:当在上下文中使用的环境已知但在创建上下文之前发送.
ApplicationPreparedEvent:在刷新开始之前但在加载bean定义之后发送
ApplicationStartedEvent:在刷新上下文之后但在调用任何应用程序和命令行运行程序之前发送。
ApplicationReadyEvent:在调用任何应用程序和命令行运行程序后发送。它表示应用程序已准备好为请求提供服务。
ApplicationFailedEvent:如果启动时有异常，则发送。
```

### 访问程序运行参数

```
import org.springframework.boot.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

@Component
public class MyBean {

    @Autowired
    #这里注入ApplicationArgument来获取启动参数
    public MyBean(ApplicationArguments args) {
        boolean debug = args.containsOption("debug");
        List<String> files = args.getNonOptionArgs();
        // 启动时加入参数 "--debug logfile.txt" debug=true, files=["logfile.txt"]
    }

}
```

### ApplicationRunner和CommandLineRunner

```
# 在程序启动后根据启动项进行一些操作
@Component
// 实现接口
public class MyBean implements CommandLineRunner {

    public void run(String... args) {
        // Do something...
    }

}
```

### 退出Application

```
@SpringBootApplication
public class ExitCodeApplication {

    @Bean
    // 返回一个结束码
    public ExitCodeGenerator exitCodeGenerator() {
        return () -> 42;
    }

    public static void main(String[] args) {
        // 这是什么模式？装饰器模式吧,一层一层委托退出
        System.exit(SpringApplication.exit(SpringApplication.run(ExitCodeApplication.class, args)));
    }

}
```

## 外部配置

spring查找配置的顺序

```
1.Devtools 主目录上的全局设置属性（~/.spring-boot-devtools.properties当devtools处于活动状态时）。
2.@TestPropertySource 测试上的注释。
3.properties属性测试。可 用于测试特定应用程序片段@SpringBootTest的 测试注释。
4.$.命令行参数。
5.来自SPRING_APPLICATION_JSON（嵌入在环境变量或系统属性中的内联JSON）的属性。
6.ServletConfig init参数。
7.ServletContext init参数。
8.JNDI属性来自java:comp/env。
9.Java系统属性（System.getProperties()）。
10.OS环境变量。
11.一RandomValuePropertySource。
12.特定于配置文件的应用程序属性在打包的jar（application-{profile}.properties和YAML变体）之外。
13.打包在jar中的特定于配置文件的应用程序属性（application-{profile}.properties 以及YAML变体）。
14.应用程序属性在打包的jar之外（application.properties和YAML变体）。
15.打包在jar中的应用程序属性（application.properties和YAML变体）。
16.@PropertySource 你的@Configuration上的注释。
17.默认属性（由设置指定SpringApplication.setDefaultProperties）。
```

### demo

```
import org.springframework.stereotype.*;
import org.springframework.beans.factory.annotation.*;

@Component
public class MyBean {

    // 注入配置的值,key为name,可以是环境变量里的可以是上述17中任何一种,通常写在第15种里
    // java -jar app.jar --name="Spring" 可以是从参数获得
    // SPRING_APPLICATION_JSON ='{“acme”：{“name”：“test”}}'java -jar myapp.jar 可以在linux中使用命令获取
    // java -Dspring.application.json ='{“name”：“test”}'-jar myapp.jar
    // java -jar myapp.jar --spring.application.json ='{“name”：“test”}'
    // 以上多种配置外部属性或者获取外部属性的方式,当然可以获取$JAVA_HOME等
    @Value("${name}")
    private String name;

    // ...

}
```

### 配置随机值

```
my.secret=${random.value}
my.number=${random.int}
my.bignumber=${random.long}
my.uuid=${random.uuid}
my.number.less.than.ten=${random.int(10)}
my.number.in.range=${random.int[1024,65536]}
```

### 访问命令行属性

```
java -jar xxx.jar --server.port=8080
server.port会被添加进Environment中
也就是可以${server.port}使用了
禁用:SpringApplication.setAddCommandLineProperties(false)
```

### 应用属性文件
application.properties和application.yml会被加入到Enviroment中

切换默认配置文件名称

```
# 配置文件交myproject.yml
java -jar myproject.jar --spring.config.name=myproject
# 指定两个配置文件
java -jar myproject.jar --spring.config.location=classpath:/default.properties,classpath:/override.properties
```

### yml,bean转换

```
yml
my:
   servers:
       - dev.example.com
       - another.example.com

prop
my.servers[0]=dev.example.com
my.servers[1]=another.example.com

bean
// 获取配置中前缀为my的
@ConfigurationProperties(prefix="my")
public class Config {

    private List<String> servers = new ArrayList<String>();

    public List<String> getServers() {
        return this.servers;
    }
}
```


### 类型安全的配置属性

```
acme:
    remote-address: 192.168.1.1
    security:
        username: admin
        roles:
          - USER
          - ADMIN



package com.example;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

# 使用acme中的配置
@ConfigurationProperties("acme")
public class AcmeProperties {

    private boolean enabled;

    private InetAddress remoteAddress;

    private final Security security = new Security();

    public boolean isEnabled() { ... }

    public void setEnabled(boolean enabled) { ... }

    public InetAddress getRemoteAddress() { ... }

    public void setRemoteAddress(InetAddress remoteAddress) { ... }

    public Security getSecurity() { ... }

    public static class Security {

        private String username;

        private String password;

        private List<String> roles = new ArrayList<>(Collections.singleton("USER"));

        public String getUsername() { ... }

        public void setUsername(String username) { ... }

        public String getPassword() { ... }

        public void setPassword(String password) { ... }

        public List<String> getRoles() { ... }

        public void setRoles(List<String> roles) { ... }

    }
}
```

具体使用

```
@Service
public class MyService {

    private final AcmeProperties properties;

    @Autowired
    public MyService(AcmeProperties properties) {
        this.properties = properties;
    }

    //...

    @PostConstruct
    public void openConnection() {
        Server server = new Server(this.properties.getRemoteAddress());
        // ...
    }

}
```

### @ConfigurationProperties验证

```
@ConfigurationProperties(prefix="acme")
@Validated
public class AcmeProperties {

    @NotNull
    private InetAddress remoteAddress;

    @Valid
    private final Security security = new Security();

    // ... getters and setters

    public static class Security {

        @NotEmpty
        public String username;

        // ... getters and setters

    }

}
```

## Profiles

```
如果你又两个或多个配置文件
application-dev.yml
application-test.yml

spring.profiles.active=dev
那被激活的是application-dev配置

用命令传参数覆盖active配置项
java -jar xxx.jar --spring.profiles.active=test
```

## 日志

默认情况下，Spring Boot仅记录到控制台，不会写入日志文件。如果除了控制台输出之外还要编写日志文件，则需要设置 logging.file.name或logging.file.path属性（例如，在您的中 application.properties）。

```
logging:
// 级别
  level:
    // root下级别为info(默认提供)
    root: info
    // hibernate日志级别(默认提供)
    hibernate: debug
    // tomcat 是分组分出来的
    tomcat: info
    // 默认提供
    web: debug
  // 单日志大小
  file:
    max-size: 10MB
    // 日志存储目录
  path: /Users/ferried/Projects/gradle-boot/src/main/resources/asdf.log
  // 建立分组(key对应包)
  // 建立好分组后在level下引用
  group:
    tomcat: org.apache.catalina, org.apache.coyote, org.apache.tomcat
```

```
logging.exception-conversion-word:LOG_EXCEPTION_CONVERSION_WORD:记录异常时使用的转换字。
logging.file.name:LOG_FILE:如果已定义，则在默认日志配置中使用它。
logging.file.max-size:LOG_FILE_MAX_SIZE:最大日志文件大小（如果启用了LOG_FILE）。（仅支持默认的Logback设置。）
logging.file.max-history:LOG_FILE_MAX_HISTORY:要保留的最大归档日志文件数（如果启用了LOG_FILE）。（仅支持默认的Logback设置。）
logging.file.path:LOG_PATH:如果已定义，则在默认日志配置中使用它。
logging.pattern.console:CONSOLE_LOG_PATTERN:要在控制台上使用的日志模式（stdout）。（仅支持默认的Logback设置。）
logging.pattern.dateformat:LOG_DATEFORMAT_PATTERN:日志日期格式的Appender模式。（仅支持默认的Logback设置。）
logging.pattern.file:FILE_LOG_PATTERN:要在文件中使用的日志模式（如果LOG_FILE已启用）。（仅支持默认的Logback设置。）
logging.pattern.level:LOG_LEVEL_PATTERN:呈现日志级别时使用的格式（默认%5p）。（仅支持默认的Logback设置。）
PID:PID:当前进程ID（如果可能，则在未定义为OS环境变量时发现）。
```

## JSON

Spring Boot提供了与三个JSON映射库的集成:Gson,Jackson,Json-b

## Developing Web Applications(开发WEB应用程序)

```
// 声明一个Controller
@RestController
// Controller路径
@RequestMapping(value="/users")
public class MyRestController {
    // 路径传参
    @RequestMapping(value="/{user}", method=RequestMethod.GET)
    // 获取路径中传递的参数
    public User getUser(@PathVariable Long user) {
        // ...
    }

    @RequestMapping(value="/{user}/customers", method=RequestMethod.GET)
    List<Customer> getUserCustomers(@PathVariable Long user) {
        // ...
    }

    @RequestMapping(value="/{user}", method=RequestMethod.DELETE)
    public User deleteUser(@PathVariable Long user) {
        // ...
    }

}
```

