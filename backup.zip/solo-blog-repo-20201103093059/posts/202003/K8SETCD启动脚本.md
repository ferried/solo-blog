title: K8S-ETCD 启动脚本
date: '2020-03-19 23:04:22'
updated: '2020-03-19 23:04:22'
tags: [k8s]
permalink: /articles/2020/03/19/1584630262465.html
---
![](https://img.hacpai.com/bing/20180604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 那就请使用这个Command吧


由于Github Release 下载下来只有 etcd 和 etcdctl 并没有 配置文件 和 systemctl.service 所以迫不得已写了个命令行,贴出来已备后用


```shell
#!/bin/bash
// name 请改成当前节点 etcd的name
// etcd 命令请指定到自己的目录
// ip地址请改成自己的地址
// pem证书目录请改成自己的目录
/opt/etcd/etcd --name etcd-1 \
		--data-dir var/lib/etcd/default.etcd \
		--listen-peer-urls https://192.168.1.109:2380 \
		--listen-client-urls https://192.168.1.109:2379,http://127.0.0.1:2379 \
		--advertise-client-urls https://192.168.1.109:2379 \
		--initial-advertise-peer-urls https://192.168.1.109:2380 \
		--initial-cluster etcd-1=https://192.168.1.119:2380,etcd-2=https://192.168.1.99:2380,etcd-3=https://192.168.1.109:2380 \
		--initial-cluster-token etcd-cluster \
		--initial-cluster-state new \
		--cert-file /opt/ssl/k8sca/etcd.pem \
		--key-file /opt/ssl/k8sca/etcd-key.pem \
		--peer-cert-file /opt/ssl/k8sca/etcd.pem \
		--peer-key-file /opt/ssl/k8sca/etcd-key.pem \
		--trusted-ca-file /opt/ssl/k8sca/ca.pem \
		--peer-trusted-ca-file /opt/ssl/k8sca/ca.pem
```