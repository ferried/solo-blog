title: SpaceVim lsp 配置
date: '2019-10-28 22:37:37'
updated: '2019-10-28 22:47:12'
tags: [SpaceVim]
permalink: /articles/2019/10/28/1572273457212.html
---
![](https://img.hacpai.com/bing/20180506.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# .SpaceVim.d/init.toml 的lsp配置
```toml
[[layers]]  
 name = "lsp"  
 filetypes=['c','go','lua','javascript','dart','python','typescript','vue','html','cpp','objc','objcapp']
```

 # dart
```
环境变量
#DART
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn
export DART_HOME=/Users/ferried/Sdks/flutter
export PATH=$PATH:$DART_HOME/bin
export PATH=$PATH:$HOME/.pub-cache/bin
```
```
# language Server
pub global activate dart_language_server
```

# go
```
# GO
export GO111MODULE=on
export GOPROXY=https://goproxy.io
export GOBIN=/Users/ferried/go/bin
export PATH=$PATH:$GOPROXY:$GOBIN
```


```
go get -u github.com/sourcegraph/go-langserver
```

# typescript

```
npm install -g typescript-language-server
```

# Vue

```
npm install vue-language-server
```

# python

```
pip3 install plys
pip3 install --user python-language-server
```

# c

```
# 这个clangd 我正在研究
```

# lua
```
git clone https://github.com/sumneko/lua-language-server.git

```

# javascript

```
npm install -g javascript-typescript-langserver
```


# bash
```
npm i -g bash-language-server
```
# css
```
npm install -g vscode-css-languageserver-bin
```
# html

```
npm install -g html-languageserver
```
