title: 关于Centos集群时间同步
date: '2020-03-19 23:00:34'
updated: '2020-03-19 23:00:34'
tags: [运维]
permalink: /articles/2020/03/19/1584630034279.html
---
![](https://img.hacpai.com/bing/20190324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 安装 chrony
yum install chrony -y

# 修改配置文件

vim /etc/chrony.config

## master

```

// 这里 写Master节点的地址 
server 111.111.111.111 iburst

# Record the rate at which the system clock gains/losses time.
driftfile /var/lib/chrony/drift

# Allow the system clock to be stepped in the first three updates
# if its offset is larger than 1 second.
makestep 1.0 3
rtcsync

# Enable hardware timestamping on all interfaces that support it.
#hwtimestamp *

# Increase the minimum number of selectable sources required to adjust
# the system clock.
#minsources 2

# Allow NTP client access from local network.
#allow 192.168.0.0/16
// 这里allow所有网段或者改成你自己的网段
allow
# Serve time even if not synchronized to a time source.
// 这里打开即使不与时间源同步，也提供时间
local stratum 10

# Specify file containing keys for NTP authentication.
#keyfile /etc/chrony.keys

# Specify directory for log files.
logdir /var/log/chrony

# Select which information is logged.
#log measurements statistics tracking
```

```
// 重启服务
systemctl restart chronyd
```

然后把文件分发到各个 子机 上
```
scp /etc/chrony.conf root@xxx:/etc/chrony.conf
```

子机重启服务

```
systemctl restart chronyd
```

查看 是否 同步成功

```
chronyc sources
```

```
210 Number of sources = 1
MS Name/IP address         Stratum Poll Reach LastRx Last sample               
===============================================================================
^* master-1                     11   9   377   502    +18us[  +31us] +/-   15ms
```
^* = 成功

^? = 不成功

不成功的原因可能是由于NTP没有开启导致
```
timedatectl set-ntp true
```
然后在重启 master node 的chronyd











