title: K8S-Scheduler 启动脚本
date: '2020-03-23 14:21:54'
updated: '2020-03-23 14:21:54'
tags: [k8s]
permalink: /k8s
---
![](https://img.hacpai.com/bing/20181223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```bash
#!/bin/bash
# 是否输出错误信息
/opt/kubernetes/server/bin/kube-scheduler --logtostderr false \
# 日志级别
		--v 2 \
# 日志目录
		--log-dir /opt/kubernetes/logs \
# 自动找主节点
		--leader-elect true \
# apiserver地址
		--master 127.0.0.1:8080 \
# 服务监听地址
		--address 127.0.0.1
```