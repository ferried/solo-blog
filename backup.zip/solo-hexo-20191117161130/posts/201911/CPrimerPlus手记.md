title: 《C Primer Plus》手记
date: '2019-11-17 10:44:36'
updated: '2019-11-17 11:27:28'
tags: [C]
permalink: /articles/2019/11/17/1573958676119.html
---
![](https://img.hacpai.com/bing/20190313.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 0.槽
现在的书大都太啰嗦，把读书的人当作傻子。这本书也不例外。
或许详细的API手册才是我所需要的吧。。。

# 1.变量

## 1.1Int
```c
//1.16位计算机 int 区间 为 -32678 - 32677所以ISO C 规定int的取值范围最小为 -32678 - 32677

// erns,dogs 并没有初始化；
int erns;
int cows = 32,goats = 14;
int dogs,cats = 69;

//打印
printf("%d",cats);
//八进制
printf("%o",0144);
// 十六进制
printf("%x",0x64);
//显示前缀
printf("%#o, %#x",0144,0x64);
```
## 1.2修饰符



```c
// short 短 比int范围短
// long 长 比int多
// long long 非常长 至少要64位机器比long长
// unsigned 无符号 非负数情况 unsigned int 0 ~ 65535
// signed 有符号 signed int - 32638 - 32637

long int estine;
long johns;
short int erns;
short ribs;
unsigned int s_count;
unsigned players;
unsigned long headcount;
unsigned short yesvotes;
long long ago;

// unsigned int  %u
printf("%u",null);
// short
printf("%h",null);
// long
printf("%ld",null);
// long long
printf("%lld",null);
// unsigned long
printf("%llu",null);

```

## 1.3char
实际上字符在memory种存储类型为int再经过码表转换成字符
码表:ASCII,kanji,Unicode,GBK,IEC10646
单char占位1bit
```c
char a = 'a';
chat A = 65;
```
非打印字符
```
\a 警报
\b 退格
\f 换页
\n 换行
\r 回车
\t 水平制表
\v 垂直制表
\\ 反斜杠 \
\' 单引号(转义)
\0oo 八进制值
\xhh 十六进制值
```
打印字符
```
printf("%c",'c');
```
## 1.4_Bool

```
true
false
```
## 1.5浮点
```c
float a = 3.11
double b = 3.1415926
long double c = 3.11111111111111111111111111111111111
```
## 1.6类型大小

```c
printf("%d",sizeof(int));
printf("%lld",sizeof(long long int));
```

## 1.7字符串

```c
//  char array = string
char str[40] = "ajskdfjslkafjlsadjfks";
// array size
printf("%d",strlen(str));
```
内存里每一个地址存一个字符，由连续的内存地址存储字符串，遇到\0后结束，\0也占用char array中的一个位置
![image.png](https://img.hacpai.com/file/2019/11/image-2f0af448.png)
```
char a = 'x';
char b[1] = "x";
```

## 1.8常量
```c
#inculde<stdio.h>
#define PI 3.14
int main(){
// 只读
const int i = 0;
printf("%0.2f",PI);
return 0;
}
```
# 2.流控运算符
都差不多:`+ - * /   %  > < =  ++ -- ! ||  & &&` 三元 ?:
```c
while(true){}

for(int i = 0 ;i < 5;i++){}

do{}while(_Bool);

if(_Bool){} else{}

if(_Bool){} else if(_Bool){}

while(true){ if(xxx){ continue;} else if(yyy){break}

switch(xxx){
	case 1:
		break;
	case 2:
		break;
	default:
		break;
}

if(size >12){ goto a}else{goto b};
a:cost = cost*=1.5
b:bill = cost*=2
```

# 3.Input/Output IO
打会儿魔兽吃完饭下午继续总结
# BULLDING
