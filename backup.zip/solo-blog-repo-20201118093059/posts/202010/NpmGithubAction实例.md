title: Npm_Github_Action 实例
date: '2020-10-21 14:23:37'
updated: '2020-10-21 14:23:37'
tags: [GitHub]
permalink: /articles/2020/10/21/1603261417165.html
---
# Yml

```yml
name: deploy
on: [release]
jobs:
  build:
    name: building
    runs-on: ubuntu-16.04
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2-beta
        with:
          node-version: "14"
      - run: npm install
      - run: npm run build
      - uses: appleboy/scp-action@master
        with:
          host: ${{ secrets.REMOTE_HOST }}
          username: ${{ secrets.REMOTE_USER }}
          password: ${{ secrets.PASSWORD }}
          port: ${{ secrets.PORT }}
          source: ".nuxt"
          target: ${{ secrets.REMOTE_TARGET}}
      - uses: docker://evaneos/ssh-action:0.1.0
        with:
          host: ${{ secrets.REMOTE_HOST }} 
          private-key: ${{ secrets.SERVER_SSH_KEY }} 
          user: ${{ secrets.REMOTE_USER }}
          port: ${{ secrets.PORT }}
          password: ${{ secrets.PASSWORD }}
          commands: ~/build.sh
```

# 如何工作?

```
on: [release]
```

当项目release了新版本触发action

```
name: building
runs-on: ubuntu-16.04
```

名称是Action Page用来显示用的，runs-on表示 job 在什么样子的系统上运行

```
steps:
   - uses: actions/checkout@v2
```

checkout code的action

一个job的具体工作，uses饮用别人写好的action，具体action作用可以在https://github.com/actions/ 搜罗，比如我需要scp文件那就搜scp，然后根据readme进行配置即可

```
- uses: actions/setup-node@v2-beta
        with:
          node-version: "14"
      - run: npm install
      - run: npm run build
```

nodejs 相关的action,由于项目类型为nodejs所以用这个，with是传入一些变量,两个run 安装依赖并打包

```yml
- uses: appleboy/scp-action@master
        with:
          host: ${{ secrets.REMOTE_HOST }}
          username: ${{ secrets.REMOTE_USER }}
          password: ${{ secrets.PASSWORD }}
          port: ${{ secrets.PORT }}
          source: ".nuxt"
          target: ${{ secrets.REMOTE_TARGET}}
```

由于代码开源所以host,username,password这种数据不可能明文写出,所以需要从项目配置里取
![image.png](https://b3logfile.com/file/2020/10/image-e39a5fdc.png)

![image.png](https://b3logfile.com/file/2020/10/image-848f2734.png)

这个action主要是将第一步打包好的静态文件scp至我们的服务器上待用

```yml
- uses: docker://evaneos/ssh-action:0.1.0
        with:
          host: ${{ secrets.REMOTE_HOST }} 
          private-key: ${{ secrets.SERVER_SSH_KEY }} 
          user: ${{ secrets.REMOTE_USER }}
          port: ${{ secrets.PORT }}
          password: ${{ secrets.PASSWORD }}
          commands: ~/build.sh
```

这个action用来ssh到我们的服务器执行commands，由于静态文件已经放入服务器，build.sh我们只要将文件放到合适的地方重启服务就好了,至于ssh的公钥和私钥请自行google

# 效果展示

![image.png](https://b3logfile.com/file/2020/10/image-b182b2b0.png)

![image.png](https://b3logfile.com/file/2020/10/image-410c87bc.png)



