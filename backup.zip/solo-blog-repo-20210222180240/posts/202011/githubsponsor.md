title: github sponsor
date: '2020-11-24 17:34:16'
updated: '2020-11-24 17:34:16'
tags: [待分类]
permalink: /articles/2020/11/24/1606210456576.html
---
# Alipay

![image.png](https://b3logfile.com/file/2020/11/image-8eb70284.png)

# WechatPay

![image.png](https://b3logfile.com/file/2020/11/image-25ef2d43.png)
