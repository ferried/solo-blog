title: 我曾经跨过VSCODE和GO
date: '2019-09-11 14:28:30'
updated: '2019-09-11 14:29:02'
tags: [Go]
permalink: /articles/2019/09/11/1568183310422.html
---
![](https://img.hacpai.com/bing/20190116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

记vscod配置golang的坑

# 1.安装go

```
brew install go
```

# 2. bash_profile

设置mod开启+代理+bin就够了

```
export GO111MODULE=on

export GOPROXY=https://goproxy.io

export GOBIN=/Users/ferried/go/bin

export PATH=$PATH:$GOPROXY:$GOBIN
```

# 3.vscode

安装插件

![image.png](https://img.hacpai.com/file/2019/09/image-6c32f4c6.png)

不要点右下角弹出来的install

输入command

![image.png](https://img.hacpai.com/file/2019/09/image-cac3285e.png)
最后喝茶到安装完毕

![image.png](https://img.hacpai.com/file/2019/09/image-3806e20d.png)


