title: 我在 GitHub 上的开源项目
date: '2019-08-20 08:36:06'
updated: '2019-08-20 08:36:06'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [hacpai-cr](https://github.com/ferried/hacpai-cr) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/hacpai-cr/watchers "关注数")&nbsp;&nbsp;[⭐️`10`](https://github.com/ferried/hacpai-cr/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/ferried/hacpai-cr/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hacpai.com/cr`](https://hacpai.com/cr "项目主页")</span>

the plugin of the vscode for the hacpai.com's chat room



---

### 2. [idea-hacpai-cr](https://github.com/ferried/idea-hacpai-cr) <kbd title="主要编程语言">Assembly</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ferried/idea-hacpai-cr/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ferried/idea-hacpai-cr/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/ferried/idea-hacpai-cr/network/members "分叉数")</span>





---

### 3. [ng-grid-layout-antd](https://github.com/hbyunzai/ng-grid-layout-antd) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/hbyunzai/ng-grid-layout-antd/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/hbyunzai/ng-grid-layout-antd/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/hbyunzai/ng-grid-layout-antd/network/members "分叉数")</span>

copy from ng2-grid-layout https://github.com/MusixNotMusic/ng2-grid-layout



---

### 4. [solo-blog](https://github.com/ferried/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ferried/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://blog.ferried.cn:8080`](http://blog.ferried.cn:8080 "项目主页")</span>

争渡 - ferried's blog



---

### 5. [vntd-layout-template](https://github.com/ferried/vntd-layout-template) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/vntd-layout-template/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/vntd-layout-template/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/vntd-layout-template/network/members "分叉数")</span>





---

### 6. [electron-sonar-client](https://github.com/ferried/electron-sonar-client) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/electron-sonar-client/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/electron-sonar-client/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/electron-sonar-client/network/members "分叉数")</span>

use electron write a client. that can generate sonar's properties for typescript/javascript



---

### 7. [ngx-wechat-qrcode](https://github.com/ferried/ngx-wechat-qrcode) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/ngx-wechat-qrcode/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/ngx-wechat-qrcode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/ngx-wechat-qrcode/network/members "分叉数")</span>

use angular to generate a qrcode for wechat'js



---

### 8. [bom-manager](https://github.com/ferried/bom-manager) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ferried/bom-manager/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ferried/bom-manager/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ferried/bom-manager/network/members "分叉数")</span>

manager system of bower that use springboot mybatis and vue.js

