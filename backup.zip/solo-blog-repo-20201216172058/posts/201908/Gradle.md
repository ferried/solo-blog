title: Gradle
date: '2019-08-19 09:07:37'
updated: '2019-08-19 09:07:37'
tags: [Gradle, Java, Package]
permalink: /articles/2019/08/19/1566176857184.html
---
![](https://img.hacpai.com/bing/20180101.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![](https://img.hacpai.com/bing/20181002.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 入门

代码打包编译工具

## 安装

```
# 安装
brew install gradle
# 查看路径
brew info gradle

gradle: stable 4.10.2
Open-source build automation tool based on the Groovy and Kotlin DSL
https://www.gradle.org/
/usr/local/Cellar/gradle/4.10.2 (203 files, 83.7MB) *
  Built from source on 2018-09-30 at 21:09:13
From: https://github.com/Homebrew/homebrew-core/blob/master/Formula/gradle.rb
==> Requirements
Required: java >= 1.7 ✔
==> Options
--with-all
	Installs Javadoc, examples, and source in addition to the binaries
==> Analytics
install: 35,101 (30 days), 139,707 (90 days), 564,602 (365 days)
install_on_request: 33,414 (30 days), 127,350 (90 days), 492,707 (365 days)
build_error: 0 (30 days)
```

路径为:/usr/local/Cellar/gradle/4.10.2/libexec

## 初始化项目

```
mkdir demo
cd demo
gradle init
```

会生成目录

```
├── build.gradle  :当前项目构建脚本
├── gradle
│   └── wrapper
│       ├── gradle-wrapper.jar   :gradle包装的jar包
│       └── gradle-wrapper.properties   :jar包配置文件
├── gradlew  :linux 脚本
├── gradlew.bat  :windows脚本
└── settings.gradle  :用于配置Gradle构建的Gradle设置脚本
```

## 开始一项任务

1.创建 src 目录<br> 2.建立 myfile.txt 并写入 hello world 3.在 build 中写入脚本

```groovy
task copy(type: Copy, group: "Custom", description: "Copies sources to the dest directory") {
    from "src"
    into "dest"
}
```

运行 copy

```
gradle copy
```

此时多出了 dest 文件夹和 myfile 文件

## 使用插件

<a href="http://plugins.gradle.org/">GRADLE 插件  库</a>

```groovy
//  加入插件
plugins {
    id "base"
}

//  写入脚本
task zip(type: Zip, group: "Archive", description: "Archives sources in a zip file") {
    from "src"
    setArchiveName "basic-demo-1.0.zip"
}
```

执行任务

```
gradle zip
```

任务执行结束多出了 build 目录下面有 basic-demo-1.0.zip,这是压缩好的 src 目录

## 查看 gradle 命令

```
gradle tasks



> Task :tasks

------------------------------------------------------------
All tasks runnable from root project
------------------------------------------------------------

Archive tasks 归档任务(zip分组group)
-------------
zip - 归档(自己写的描述)

Build tasks 构建任务
-----------
assemble - 汇总项目输出
build - 打包并测试项目
clean - 删除打包文件

Build Setup tasks 构建安装任务
-----------------
init - 初始化gradle项目
wrapper - 生成gradle包文件

Custom tasks 自定义任务
------------
copy - Copies sources to the dest directory(第一个任务自己写的描述)

Help tasks
----------
buildEnvironment  - 显示在根项目中声明的所有buildscript依赖项。
components  - 显示根项目生成的组件。
dependencies  - 显示在根项目中声明的所有依赖项。
dependencyInsight  - 显示对根项目中特定依赖项dependentComponents  - 显示根项目中组件的相关组件。
help  - 显示帮助消息。
model  - 显示根项目的配置模型。
projects  - 显示根项目的子项目。
properties  - 显示根项目的属性。
tasks  - 显示可从根项目运行的任务。

Verification tasks
------------------
check - 运行所有检查项

Rules
-----
Pattern: clean<TaskName>: 清除任务的输出文件。
Pattern: build<ConfigurationName>:  组装配置。 upload<ConfigurationName>: 组装并上传属于配置。

To see all tasks and more detail, run gradle tasks --all

To see more detail about a task, run gradle help --task <task>

BUILD SUCCESSFUL in 0s
1 actionable task: 1 executed
```

# 构建 java 应用程序

## 初始化项目

```groovy
gradle init --type <name>

name可选项:
java-application
java-library
scala-library
groovy-library
basic
```

选用 java-application

```
mkdir gradle-java-demo
cd gradle-java-demo
gradle init --type java-application
```

## 项目结构

```
├── build.gradle 构建脚本
├── gradle
│   └── wrapper
│       ├── gradle-wrapper.jar 构建包
│       └── gradle-wrapper.properties 构建包配置
├── gradlew linux构建脚本
├── gradlew.bat windows构建脚本
├── settings.gradle 项目设置(主要有项目名称)
└── src
    ├── main
    │   └── java
    │       └── App.java 主类
    └── test
        └── java
            └── AppTest.java 测试类
```

## 脚本结构

```groovy
//  插件
plugins {
    //  java插件
    id 'java'
    //  application插件
    id 'application'
}

//  入口
//  具有“main”方法的类（由Application插件使用）
mainClassName = 'App'

//  项目依赖
dependencies {
    compile 'com.google.guava:guava:23.0'
    //  测试依赖
    testCompile 'junit:junit:4.12'
}

//  公共依赖库
repositories {
    jcenter()
}

```

## 构建项目

```
gradle build

$ ./gradlew build
> Task :compileJava
> Task :processResources NO-SOURCE
> Task :classes
> Task :jar
> Task :startScripts
> Task :distTar
> Task :distZip
> Task :assemble
> Task :compileTestJava
> Task :processTestResources NO-SOURCE
> Task :testClasses

> Task :test

> Task :check
> Task :build

BUILD SUCCESSFUL
```

# 构建 java 库

## 初始化项目

```
# 初始化项目
mkdir gradle-java-library
cd gradle-java-library
gradle init --type java-library
```

## 目录结构

```
.
├── build.gradle 构建脚本
├── gradle
│   └── wrapper
│       ├── gradle-wrapper.jar 构建包
│       └── gradle-wrapper.properties 构建包配置
├── gradlew 构建shell命令
├── gradlew.bat 构建批处理命令
├── settings.gradle 项目设置
└── src
    ├── main
    │   └── java
    │       └── Library.java
    └── test
        └── java
            └── LibraryTest.java
```

## 脚本结构

```groovy
//  插件
plugins {
    //  这是java-base插件的扩展，并添加了用于编译Java源代码的其他任务
    id 'java-library'
}

//  依赖
dependencies {
    //  公共依赖存储库
    api 'org.apache.commons:commons-math3:3.6.1'
    //  依赖于google包
    implementation 'com.google.guava:guava:23.0'
    //  测试依赖包
    testImplementation 'junit:junit:4.12'
}

//  公共依赖库
repositories {
    jcenter()
}
```

## 打包 jar

```
gradle build
```

## 自定义 jar 包信息

```groovy
//  版本
version = '0.1.0'
```

## 注释文档

```
gradle javadoc
```

生成文档在 build/doc 目录下

# JAVA 项目依赖  管理

## 解析脚本

```groovy
apply plugin: 'java-library'

repositories {
    mavenCentral()
}

dependencies {
    implementation 'org.hibernate:hibernate-core:3.6.7.Final'
    api 'com.google.guava:guava:23.0'
    testImplementation 'junit:junit:4.+'
}
```

1.implementation 说明项目依赖了 hibernate3.6.7<br>
2.testImplementation 说明项目测试要用 junit > 4.0 版本<br> 3.所有的依赖会在 repositories 中去查找<br>

## 使用本地仓库 url

```groovy
  repositories {
    ivy {
        // 本地路径
        url "../local-repo"
    }
}
```

# 发布library

## 创建任务

```groovy
task myJar(type: Jar)

artifacts {
    archives myJar
}
```

## 文件

```groovy
def someFile = file('build/somefile.txt')

artifacts {
    archives someFile
}
```

## 自定义

```groovy
task myTask(type:  MyTaskType) {
    destFile = file('build/somefile.txt')
}

artifacts {
    archives(myTask.destFile) {
        name 'my-artifact'
        type 'text'
        builtBy myTask
    }
}
```

## 映射

```groovy
task generate(type:  MyTaskType) {
    destFile = file('build/somefile.txt')
}

artifacts {
    // 映射
    archives file: generate.destFile,
    name: 'my-artifact',
    type: 'text',
    builtBy: generate
}
```

## 发布

```groovy
repositories {
    flatDir {
        name "fileRepo"
        dirs "repo"
    }
}

uploadArchives {
    repositories {
        // 文件
        add project.repositories.fileRepo
        ivy {
            // 自定义仓库用户名密码
            credentials {
                username "username"
                password "pw"
            }
            // url
            url "http://repo.mycompany.com"
        }
    }
}
```

# 用户手册

<a href="https://docs.gradle.org/current/userguide/userguide.html">Gradle用户手册</a>