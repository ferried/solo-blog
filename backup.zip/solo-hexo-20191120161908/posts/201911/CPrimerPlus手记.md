title: 《C Primer Plus》手记
date: '2019-11-17 10:44:36'
updated: '2019-11-19 22:00:29'
tags: [C]
permalink: /articles/2019/11/17/1573958676119.html
---
![](https://img.hacpai.com/bing/20190313.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 0.槽
现在的书大都太啰嗦，把读书的人当作傻子。这本书也不例外。
或许详细的API手册才是我所需要的吧。。。

# 1.变量

## 1.1Int
```c
//1.16位计算机 int 区间 为 -32678 - 32677所以ISO C 规定int的取值范围最小为 -32678 - 32677

// erns,dogs 并没有初始化；
int erns;
int cows = 32,goats = 14;
int dogs,cats = 69;

//打印
printf("%d",cats);
//八进制
printf("%o",0144);
// 十六进制
printf("%x",0x64);
//显示前缀
printf("%#o, %#x",0144,0x64);
```
## 1.2修饰符



```c
// short 短 比int范围短
// long 长 比int多
// long long 非常长 至少要64位机器比long长
// unsigned 无符号 非负数情况 unsigned int 0 ~ 65535
// signed 有符号 signed int - 32638 - 32637

long int estine;
long johns;
short int erns;
short ribs;
unsigned int s_count;
unsigned players;
unsigned long headcount;
unsigned short yesvotes;
long long ago;

// unsigned int  %u
printf("%u",null);
// short
printf("%h",null);
// long
printf("%ld",null);
// long long
printf("%lld",null);
// unsigned long
printf("%llu",null);

```

## 1.3char
实际上字符在memory种存储类型为int再经过码表转换成字符
码表:ASCII,kanji,Unicode,GBK,IEC10646
单char占位1bit
```c
char a = 'a';
chat A = 65;
```
非打印字符
```
\a 警报
\b 退格
\f 换页
\n 换行
\r 回车
\t 水平制表
\v 垂直制表
\\ 反斜杠 \
\' 单引号(转义)
\0oo 八进制值
\xhh 十六进制值
```
打印字符
```
printf("%c",'c');
```
## 1.4_Bool

```
true
false
```
## 1.5浮点
```c
float a = 3.11
double b = 3.1415926
long double c = 3.11111111111111111111111111111111111
```
## 1.6类型大小

```c
printf("%d",sizeof(int));
printf("%lld",sizeof(long long int));
```

## 1.7字符串

```c
//  char array = string
char str[40] = "ajskdfjslkafjlsadjfks";
// array size
printf("%d",strlen(str));
```
内存里每一个地址存一个字符，由连续的内存地址存储字符串，遇到\0后结束，\0也占用char array中的一个位置
![image.png](https://img.hacpai.com/file/2019/11/image-2f0af448.png)
```
char a = 'x';
char b[1] = "x";
```

## 1.8常量
```c
#inculde<stdio.h>
#define PI 3.14
int main(){
// 只读
const int i = 0;
printf("%0.2f",PI);
return 0;
}
```
# 2.流控运算符
都差不多:`+ - * /   %  > < =  ++ -- ! ||  & &&` 三元 ?:
```c
while(true){}

for(int i = 0 ;i < 5;i++){}

do{}while(_Bool);

if(_Bool){} else{}

if(_Bool){} else if(_Bool){}

while(true){ if(xxx){ continue;} else if(yyy){break}

switch(xxx){
	case 1:
		break;
	case 2:
		break;
	default:
		break;
}

if(size >12){ goto a}else{goto b};
a:cost = cost*=1.5
b:bill = cost*=2
```

# 3.Input/Output IO

```c
// 获取字符
getchar();
// 输出字符
putchar()
```

```c
// echo
#include<stdio.h>
int main(void){
char ch;
// 如果不输入 # 那么一直读字符
while((ch = getchar()) != '#'){
	// 同时一直输出字符
	putchar(ch);
}
return 0;
}

// 无缓冲
char a = 'a'
// 将字符存入缓冲区
getchar();
```
完全缓冲:当缓冲区被填满时才刷新缓冲区
行缓冲:当出现换行符时刷新缓冲区,enter刷新缓冲区

```c
#include<stdio.h>
#include<stdlib.h>
int main()
{
int ch;
// 文件类型指针
FILE * fp;
char fname[50];
printf("Enter the name of the file");
scanf("%s",fname);
// 打开输入的文件 并用指针指向该文件，以r读权限打开
fp = fopen(fname,"r");
// 如果空指针，证明没有文件
if(fp == NULL){
	printf("no file");
}
// 循环读取文件中的每一个字符最后打印
while((ch = getc(fp))!=EOF){
	putchar(ch);
}
// 关闭文件
fclose(fp);
}
```

# 4.函数

```c
#inculde<stdio.h>
// 书写函数前要声明,不带参数，无返回值
void say(void);
// 返回int值带两个int型参数
int sum(int a,int b);
int main(void){
say();
return 0;
}

void say(){
putchar("H");
}
int sum(int a,int b){return a+b};
```
# 5.指针
```c
// int类型的值
int a = 0;
// &为寻址符，查找a的内存地址
printf("%p",&a);
// 声明指针b
int * b;
// 将a的地址给b
b = a;
// 格式化输出地址
printf("%p",b);
```
# 6.数组二维数组

```c
int main(){
	int a[10] = {1,2,3,4,5,6,7,8,9,0}
	int * b;
	printf("%d",a[0]);
	// 将 a 的首元素地址给了指针b
	b = a;
	// *b 表示 首元素地址所指向的值
	printf("%d",*b);
	// *(b + 1) = a[1]
	printf("%d",*(b+1));
	// *b + 1 = a[0] + 1 = 2
	printf("%d",*b+1);	

	for(int i = 0;i < 10;i++) printf("%d",*(b+i));
}
```
```c
#include<stdio.h>
#define ROWS  3
#define COLS 2

int main(void){
	int array[ROWS][COLS] = {{1,2},{3,4},{5,6}}
	for(int i = 0;i<ROWS;i++){
		for(int j = 0;j<COLS;j++){
			printf("%d",array[i][j]);
		}
	}
	// 创建一个指针，指向一个含有ROS个元素的数组
	int (*pa)[ROWS];
	printf("array[0][0] = %d",**pa);
	// *pa为第一组的地址值,+1为第一组元素的第二个元素的地址值
	printf("array[0][1] = %d",*(*pa+1));
	// pa为第一组元素整体的地址值，+1 移动到第二组元素,外层指针获取第二组第一个元素的地址又加了一个地址所以为第二组元素第二个位置的值
	printf("array[1][1] = %d ",*(*(pa+1)+1));
}


```
注意，指针和数据类型都具有一定的兼容性，具体规则为 
`长度大类型/指针 = 长度小类型/指针`比如`long a; int b = 10; a = b;`
声明指针类型函数
```c
void somefunction(int (*pt)[4]);
void somefunction(int [][4]);
```
PS:变长数组不是说数组的长度可变，而是声明数组时可以使用变量指定数组的维度

# 7.复合字面量
不用声明直接用的变量,也称不上变量。。。
```c
// 没有声明的数组，只能直接传递进函数/表达式
(int[2]){10,20}

int sum(const in ar[],int n);

sum((int [3]){1,2,3},3);
```
# 8.字符串
c里面没有提供字符串的实现，只有字符数组

```c
// 第一位 a ,第二位 "\0"标志字符串结束
char a[1] = "a"
```

```c
#include <stdio.h>
#define MSG "I am a symbolic string constant."
#define MAXLENGTH 81

int main(void) {
 // 声明字符串
  char words[MAXLENGTH] = "I am a string in array.";
 // 用指针直接声明字符串
  const char *p1 = "Somethings is pointing at me.";
// puts,属于stdio.h 的输出函数,只显示字符串
  puts("Here are somt things.");
  puts(MSG);
  puts(words);
  puts(p1);
  words[8] = 'p';
  puts(words);
}
```
指针，和数组指针一个道理
```c
char car[10] = "Tata";
car == &car[0]
*car == 'T'
*(car+1) == car[1] == 'a'
// *pt1可以改变
const char *pt1 = "Some thing is pointing at me"
// ar1不能改变
const char ar1[] = "Some thing is pointing at me"
```
  

```c
#include <stdio.h>
#define SLEN 40
#define LIM 5
int main(void) {
// 5个指针的数组,五个字符串存在静态内存中,指针指向他们
  const char *mytalents[LIM] = {
      "Adding numbers swiftly", "Multiplying accurately", "Stashing data",
      "Following instructions to the letter", "Understanding the C language"};
// 5个数组的数组
  char yourtalents[LIM][SLEN] = {"Walking in a straight line", "Sleeping",
                                 "Watching television", "Mailling letters",
                                 "Reading email"};

  int i;
  puts("Let's compare talents");
  printf("%-36s %-25s \n", "MyTalens", "YourTablens");
  for (i = 0; i < LIM; i++) {
    printf("%-36s %-25s \n", mytalents[i], yourtalents[i]);
  }
  //指针占了40字节而数组占了200字节
  printf("\nsizeof mytalents: %zd, sizeof yourtalents: %zd", sizeof(mytalents),
         sizeof(yourtalents));
}
```
copy
```c
#include<stdio.h>

int main(void)
{
  const char * mesg = "Don't be a fool!";
  const char * copy;
  copy = mesg;

  printf("%s\n",copy);
 // 两个地址都一样，所以字符串没有被copy
 // 只是copy指向了mesg所指向的静态区域的字符串
  printf("%p\n",mesg);
  printf("%p\n",copy);
}
```
## 8.1 函数
gets();
```c
char words[80];
//Input 一些字符读取到words里面
gets(words);
puts("%s",words);
```
fgets,fputs,由于gets()不限定长度，所以可能会擦除使用的内存来存储字符串，是极为不安全的，所以出现了fgets,fputs
```c
char words[5];
// fgets 传入 要接受输入的字符串变量，字符串长度，输入流
fgets(words,5,stdin);
// fputs 传入 输出的字符串变量，输出流
fputs(words,stdout);
```

demo

```c
#include <stdio.h>
#define STLEN 10

int main(void) {
  // 初始化
  char words[STLEN];
  int i;
  puts("Enter strings (empty line to quit):");
  // 循环读取字符
  while (fgets(words, STLEN, stdin) != NULL && words[0] != '\n') {
    i = 0;
    // 循环便利字符串
    while (words[i] != '\n' && words[i] != '\0') {
      i++;
    }
    // 如果 遇到换
    if (words[i] == '\n') {
      // 直接截断
      words[i] = '\0';
    } else {
      while (getchar() != '\n') {
        continue;
      }
    }
    puts(words);
  }
  puts("done");
  return 0;
}
```
丢弃读到的\n换行符
gets_s()

```c
char words[20];
gets_s(words,20);
```

scanf() 走连续的单词，

```c
#include <stdio.h>

int main(void) {

  char name1[11],name2[11];
  int count;

  printf("Please enter 2 names.\n");
 // 输入过多也会导致内存溢出，加上字段宽度限定符可解决
  count = scanf("%5s %10s",name1,name2);

  printf("Iread the %d names %s and %s.\n",count,name1,name2);
}
```
输出函数 put(),fputs(),printf();

简而言之put/puts遇到空字符结束输出
fputs针对file类型文件进行输出
printf格式化输出

strlen() 获取字符串长度

```c
void fit(char *string,unsigned int size){
	if(strlen(string)>size){
		string[size]="\0"
	}
}
```

strcat() 拼接字符串

```c
char a[1] = "1"
char b[1] = "2"
strcat(a,b);
```
strncat()
无法检查第一个数组是否能容纳第二个数组，如果空间不够大，会溢出到相邻的存储单元
```c
if(strlen(a) + strlen(b) <=2){
	strncat(a,b);
}
```
strcmp() 码表排序比较
```c
strcmp("A","A") = 0
strcmp("A","B") = -1
strcmp("C","A") = 1
// 逐个比较至 a 和 空字符 ，码表开头为空字符，所以返回1
strcmp("appa","app") = 1
```
strncmp(); 
```c
strncmp("abcde","abcdef",5) == 0
```
strcp strncp

```c
// 把b的字符串复制到a指向的内存 含有\0
strcp(a,b);
//表示把src所指向的字符串中以src地址开始的前n个字节复制到dest所指的数组中，并返回被复制后的dest
strncpy(char *dest, const char *src, int n)
```
// 查找c在s重的位置返回指针,找不到返回空指针
strchr(const char*s ,char c);
// 返回s1字符串中s2字符串首次出现的位置，没有就返回空指针
strstr(const char*s1,const char*s2);

demo:字符串排序
```c
#include <stdio.h>
#include <string.h>
// 限制字符串长度
#define SIZE 81
// 可读入最多行数
#define LIM 20
// 空字符停止输入
#define HALT ""
// 字符串排序
void stsrt(char *strings[], int n);
char *s_gets(char *st, int n);

int main(void) {
  // 存储输入数组
  char input[LIM][SIZE];
  // 内含指针变量的数组
  char *ptstr[LIM];
  // 输入计数
  int ct = 0;
  // 输出计数
  int k;

  printf("Input up to %d lines,and I will sort them.\n", LIM);
  printf("To Stop,press Enter key at a line's start.\n");
  while (ct < LIM && s_gets(input[ct], SIZE) != NULL && input[ct][0] != '\0') {
    ptstr[ct] = input[ct];
    ct++;
  }
  stsrt(ptstr,ct);
  puts("\n Here's the sorted list:\n");
  for(k =0;k<ct;k++)
  {
    puts(ptstr[k]);
  }
}

void stsrt(char *strings[], int n) {
  char *temp;
  int top, seek;

  for (top = 0; top < n - 1; top++) {
    for (seek = top + 1; seek < n; seek++) {
      if (strcmp(strings[top], strings[seek]) > 0) {
        temp = strings[top];
        strings[top] = strings[seek];
        strings[seek] = temp;
      }
    }
  }
}

char *s_gets(char *st, int n) {
  char *ret_val;
  int i = 0;
  // 获取输入
  ret_val = fgets(st, n, stdin);
  // 如果输入的不为空
  if (ret_val != NULL) {
    // 循环输入的字符，遇到\n或者\0截止
    while (st[i] != '\n' && st[i] != '\0') {
      i++;
    }
    // 如果循环到了 '\n'换行符，直接截断
    if (st[i] == '\n') {
      st[i] = '\0';
    } else {
      // 循环获取输入
      while (getchar() != '\n') {
        continue;
      }
    }
  }
  return ret_val;
}
```
## 8.2 Command Line Interface
Command 命令行 参数/参数个数/参数转换
```c
#include <stdio.h>
#include <stdlib.h>
void argTemplate(char **argv, int);

int main(int argc, char *argv[]) {
  int count;
  printf("The command Line has %d arguments:\n", argc - 1);
  for (count = 1; count < argc; count++) {
    printf("%d:%s\n", count, argv[count]);
  }
  printf("\n");
  argTemplate(argv,argc);
  return 0;
}

void argTemplate(char **argv, int length) {
  int i, times;
// atoi 把 argv的参数转换成int 传递给times
// atof 把 字符串转换成double
// atol 把字符串转换成long
// strtol()  strtod() strtoul() 字符串转long double unsigned long 找规律吧

  if (length < 2 || (times = atoi(argv[1])) < 1) {
    printf("Usage: %s positive-number\n",argv[0]);
  }
  else{
    for(i =0 ;i<times;i++)
    {
      puts("Template String Array!");
    }
  }
}
```

1.C字符串是char数组，内存中结尾为\n;
2.字符串常量也叫做字符串字面量;
3.函数使用指向字符串的指针，实质是指向内存字符数组的首个元素的地址;
4.fgets获取一行输入,puts(),fputs()显示一行输出;
5.C中有多个处理字符串的函数，在string.h中和ctype.h中
6.main可以接受两个参数，第一个参数为参数个数，第二个参数为所有参数
7.atoi,atol,atof把字符串转换成int,long,double,等等

# 9.存储类别链接和内存管理

```
概念:
每个值都占用一定的物理内存,C把这样一块儿内存称为对象Object
对象可以存储一个多个值,或者并未存储实际值，但是在存储时一定具有相应的大小空间
int entity = 3
entity(identifier)标识符：用来指定(designate)特定对象的内容(左值)
存储期(storage duration): 对象在内存中存了多久
作用域(scope): 标识符在哪里可以用
链接(linkage): 作用域和链接描述了程序哪部份可以使用标识符
```

private file scope
```c
static int dodgers =3;
int main(){
...
}
```
public file scope
```c
int giants =5;
int main(){
...
}
```
C对象有四中存储期:静态存储，线程存储，自动存储，动态分配
静态存储：程序的执行期间一直存在
线程存储：从被声明时到线程结束
自动存储：块作用域里的变量

| 存储类别 | 存储期 | 作用域 | 链接 | 声明方式 |
| --- | --- | --- |--- |--- |
| 自动 | 自动 | 块 | 无 | 块内 |
| 寄存器 | 自动 | 块 | 无 | 块内使用register |
| 静态外部链接 | 静态 | 文件 | 外部 | 所有函数外 |
| 静态内部链接 | 静态 | 文件 | 内部 | 所有函数外使用static |
| 静态无链接 | 静态 | 块 | 无 | 块内使用static |

auto:比如静态外部链接有 number,你要在块中定义number,又不希望标识冲突，可以用 auto int number;

外部链接静态变量使用:extern,
```c
int Errupt;
double Up[100];
extern char Coal;
```
当别的文件需要使用Coal时
```c
int main(void){
// 声明
extern char Coal;
}
```
```c
#include <stdio.h>

void report_count();
void accumulate(int);
int count = 0;
int main(void) {
  // 自动变量
  auto int value;
  // 寄存器变量
  register int i;

  while (scanf("%d", &value) == 1 && value > 0) {
    // 文件作用域变量
    ++count;
    for (i = value; i >= 0; i--) {
      accumulate(i);
    }
    report_count();
    return 0;
  }
}

void report_count(){
	printf("%d",count);
}
```

```c
#include <stdio.h>

// 引用式声明,外部链接
extern int count;
//静态定义内部变量
static int total = 0;
void accumulate(int);

// int k 块级变量
void accumulate(int k) {
  // 静态内部变量无链接
  static int subtotal = 0;
  if (k < 0) {
    printf("llop cycle:%d\n", count);
    subtotal = 0;
  } else {
    subtotal += k;
    total += k;
  }
}
```

# BULLDING



