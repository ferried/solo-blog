title: 关于微前端实现原理与ngx-planet(二)
date: '2021-01-22 14:52:30'
updated: '2021-01-23 15:24:02'
tags: [前端]
permalink: /articles/2021/01/22/1611298349966.html
---
<!--
 * @Author: ferried
 * @Email: harlancui@outlook.com
 * @Date: 2021-01-22 15:02:37
 * @LastEditTime: 2021-01-23 15:21:58
 * @LastEditors: ferried
 * @Description: Basic description
 * @FilePath: /undefined/Users/ferried/ngx-planet2.md
 * @LICENSE: Apache-2.0
-->

# 道标

准备好源码，然后跟着文章去看代码，在每个代码块的第一行，我都把 filename 写上了，并且打开了 gitalk。

# 项目结构

```
- packages/planet
|--src
    |--application
        |--planet-application-loader.spec.ts
        |--planet-application-loader.ts # 应用加载器
        |--planet-application-ref.spec.ts
        |--planet-application-ref.ts # 应用的引用
        |--planet-application.service.spec.ts
        |--planet-application.service.ts # 应用逻辑处理Service
        |--portal-application.spec.ts
        |--portal-application.ts  # Portal应用
    |--component
        |--planet-component-loader.spec.ts
        |--planet-component-loader.ts # 组件加载器
        |--planet-component-ref.ts # 组件引用
        |--plant-component.config.ts # 组件配置
    |--empty
        |--empty.component.spec.ts
        |--empty.component.ts   # 空组件
    |--testing
        |--app1.module.ts # 测试用例
        |--app2.module.ts
        |--applications.ts
        |--index.ts
        |--utils.ts
    |--assets-loader.spec.ts
    |--assets-loader.ts    # 静态资源加载器
    |--global-event-dispatcher.spec.ts
    |--global-event-dispatcher.ts   # 全局事件调度器
    |--global-planet.spec.ts
    |--global-planet.ts     # 一些函数
    |--helper.spec.ts
    |--helper.ts    # 一些util函数
    |--module.spec.ts
    |--module.ts    # packager module
    |--planet.class.ts  # 注入配置和InjectToken
    |--planet.spec.ts
    |--planet.ts    # planet 对象，包含了注册，启动设置信息，实质为service
    |--public-api.ts  # 桶
    |--test.ts # 测试
|--karma.config.js  # test config
|--ng-package.json  # packager scheme
|--pakcage.json     # npm
|--tsconfig.lib.json    # compiler config
|--tsconfig.lib.prod.json # env=prod compiler config
|--tsconfig.spec.json   # test copiler config
|--tslint.json  # code lint rules
```

# 从 Portal 的 AppComponent 开始

```ts
    // appcomponent.ts
    // 首先注入了 planet 对象
    constructor(
        private planet: Planet,
    ) {}
```

```ts
    // appcomponent.ts
    // 初始化AppComponent中配置Portal和Applications
   ngOnInit() {
       ...
   }
```

```ts
// appcomponent.ts
// 设置PlanetApplicationLoader应用加载器的options
this.planet.setOptions({
  // switchMode
  switchMode: SwitchModes.coexist,
  // Application资源加载错误处理回调函数
  errorHandler: (error) => {
    // thy组件库的通知组件，理解成alert吧
    this.thyNotify.error(`错误`, "加载资源失败");
  },
});
```

```ts
// planet.class.ts
// SiwtchModes枚举类，切换子应用的模式，默认切换会销毁，设置 coexist 后只会隐藏
export enum SwitchModes {
  default = "default",
  coexist = "coexist",
}
```

```ts
    // planet-application-loader.ts
    // Injectable直接注到模块里了(唯一),项目启动会通过Factory自行创建,所以不需要初始化
    @Injectable({
        providedIn: 'root'
    })
    export class PlanetApplicationLoader {
    private firstLoad = true;

    private startRouteChangeEvent: PlanetRouterEvent;

    // 这里是ApplicationLoader中的option
    private options: PlanetOptions

    ......

    }

```

```ts
// appcomponent.ts
// 向planet注册了两个应用
this.planet.registerApps([
  {
    // 子应用名
    name: "app1",
    // 应用渲染的容器元素, 指定子应用显示在哪个元素内部
    hostParent: "#app-host-container",
    // 宿主元素的 Class，也就是在子应用启动组件上追加的样式
    hostClass: appHostClass,
    // 子应用路由路径前缀，根据这个匹配应用
    routerPathPrefix: /\/app1|app4/,
    // 脚本和样式文件路径前缀，多个脚本可以避免重复写同样的前缀
    resourcePathPrefix: "/static/app1/",
    // 是否启用预加载，启动后刷新页面等当前页面的应用渲染完毕后预加载子应用
    preload: settings.app1.preload,
    // 切换子应用的模式，默认切换会销毁，设置 coexist 后只会隐藏
    switchMode: settings.app1.switchMode,
    // 是否串行加载脚本静态资源
    loadSerial: true,
    // 样式前缀
    stylePrefix: "app1",
    // 脚本资源文件
    scripts: ["main.js"],
    // 样式资源文件
    styles: ["styles.css"],
    // 应用程序打包后的脚本和样式文件替换
    manifest: "/static/app1/manifest.json",
    // 附加数据，主要应用于业务，比如图标，子应用的颜色，显示名等个性化配置
    extra: {
      name: "应用1",
      color: "#ffa415",
    },
  },
  .......
]);
```

在看 `planet.registerApps`之前先看一下 `GlobalPlanet`

```ts
// global-planet.ts
// 浏览器window对象
declare const window: any;

// interface
export interface GlobalPlanet {
  // 这里是一个Map,key是String类型的，Value为应用的引用
  apps: { [key: string]: PlanetApplicationRef };
  // 基座模式，只需要一个Portal
  portalApplication?: PlanetPortalApplication;
  // 应用加载器
  applicationLoader?: PlanetApplicationLoader;
  // service,函数
  applicationService?: PlanetApplicationService;
}

// 全局变量，如果window.planet不为空那么就拿window.planet的值，不然就初始化一个app的map出来
export const globalPlanet: GlobalPlanet = (window.planet = window.planet || {
  apps: {},
});

// 先看一眼，下面会在回来看
export function defineApplication(
  name: string,
  options: BootstrapAppModule | BootstrapOptions
) {
  if (globalPlanet.apps[name]) {
    throw new Error(`${name} application has exist.`);
  }
  if (isFunction(options)) {
    options = {
      template: "",
      bootstrap: options as BootstrapAppModule,
    };
  }
  const appRef = new PlanetApplicationRef(name, options as BootstrapOptions);
  globalPlanet.apps[name] = appRef;
}
```

为了继续看 `defineApplication`先看一个用例,这个用例是 `app1`的 `main.ts`中的

```ts
// app1的 main.ts
// 调用defineApplication 传入
// 1. app1,
// 2.函数返回 ModuleRef 启动的模块
defineApplication('app1', {

    // template 为一个dom字符串
    template: `<app1-root class="app1-root"></app1-root>`,

    // bootstrap 应用的加载点
    bootstrap: (portalApp: PlanetPortalApplication) => {

    // platformBrowserDynamic 传入 Provider, Provider同于 app.module中的providers 提供服务用的，作者在这里插入了两个 值或对象
    >>>>  export declare const platformBrowserDynamic: (extraProviders?: StaticProvider[] | undefined) => PlatformRef;
        return platformBrowserDynamic([
            // 其实提供服务也可以理解成有一个Context,把Value注入到Context中了，在项目中的Context中可以通过Inject方式来提取使用这个服务了
            {
                provide: PlanetPortalApplication,
                // 注意这里传入的是 defineApplication 函数 第二参数options中 BootstrapAppModule中的回调参数
                useValue: portalApp
            },
            ...
        ])
        // 引导AppModule模块,创建@NgModule实例也就是创建一个AppModule出来
            .bootstrapModule(AppModule)
            .then(appModule => {
                // 最后返回Promise<NgModule>
                // 至此，第二参中的BootstrapAppModule结束
                return appModule;
            })
            .catch(error => {
                console.error(error);
                return null;
            });
    }
});

```

好，现在返回 `defineApplication`中去看看用两个参数做了些什么呢

```ts
// planet-applicaiton.ref.ts

// 这是第二参的类型
export interface BootstrapOptions {
  template: string;
  bootstrap: BootstrapAppModule;
}

// 第二参数中 bootstrap 要传入portalApp然后返回NgModuldeRef
export type BootstrapAppModule = (
  portalApp?: PlanetPortalApplication
) => Promise<NgModuleRef<any>>;
```

上面已经讲过怎么用了,下面看当调用时，包内发生了什么?

```ts
// global-planet.ts
export function defineApplication(
  name: string,
  options: BootstrapAppModule | BootstrapOptions
) {
  // 首先，看看globalPlanet的app map中有没有加入过这个项目，也就是说，如果有10个应用，调用defineApplication时传入相同的第一参name,就会发生应用重复，无法分别当前需要加载的是哪个应用，作者在这里判断并抛出异常
  if (globalPlanet.apps[name]) {
    throw new Error(`${name} application has exist.`);
  }
  // 其次，看options第二参数，是带template的Bootstrap函数还是直接就是bootstrap函数
  if (isFunction(options)) {
    // 如果是函数，那么template为空，第二参数转化类型,options备用
    options = {
      template: "",
      bootstrap: options as BootstrapAppModule,
    };
  }
  // 这里比较关键了，通过name和options new了一个PlanetApplicationRef对象
  const appRef = new PlanetApplicationRef(name, options as BootstrapOptions);
  // 将appRef也就是子applicaiton的引用加入globalPlanet.apps的map中，也就是window.planet.apps中,至于为什么，前面有提到
  globalPlanet.apps[name] = appRef;
}
```

看看如何 new 一个子应用引用对象吧~

```ts
// planet-application-ref.ts

export class PlanetApplicationRef{
    ...

private innerSelector: string;
// 这里 将 innerSelector调用方式改为了 app.selector因为是私有变量嘛
public get selector() {
    return this.innerSelector;
}

// 首先，构造函数两个参数由defineApplication传递过来
 constructor(name: string, options: BootstrapOptions) {
     // 传递一些值给当前对象的属性
        this.name = name;
        if (options) {
            this.template = options.template;
            // 如果template被传入了 getTagNameByTemplate,由于是util不在赘述，这里拿到了标签名称，稍后看一个应用demo
            this.innerSelector = this.template ? getTagNameByTemplate(this.template) : null;
            // 将Promise<NgModuleRef>也就是bootstrap Instance也传进来
            this.appModuleBootstrap = options.bootstrap;
    }
 }
```

> 作者每一个属性名和变量的词语都非常精准，所以导致看代码的时候非常好看,非常干净,这也是 clean code 第一章所追求的,我所追求的代码风格，非常棒

看一个 selecor 应用 demo

```ts
// planet-application-loader.ts
// 首先通过name获取ApplicationRef引用
  private hideApp(planetApp: PlanetApplication) {
        const appRef = getPlanetApplicationRef(planetApp.name);
        // 获取插入的整体dom节点的document,通过selector
        const appRootElement = document.querySelector(appRef.selector || planetApp.selector);
        // 隐藏dom元素
        if (appRootElement) {
            appRootElement.setAttribute('style', 'display:none;');
        }
    }
```


构建中...
