title: Antv_G2笔记
date: '2020-11-13 16:36:44'
updated: '2020-11-13 16:38:42'
tags: [Antv]
permalink: /articles/2020/11/13/1605256604675.html
---
# 1.七个元素

## 1.1数据

就是数据，把整理好的数据灌入g2中

```ts
chart.data(data);
```

## 1.2 图形属性

## 1.3 几何标记

一种标记对应着一种图形,比如点图 `chart.point`区域图 `chart.area`区间图 `chart.interval`

```ts
declare module './chart/view' {
    interface View {
        /**
         * 创建 Polygon 几何标记。
         * @param [cfg] 传入 Polygon 构造函数的配置。
         * @returns polygon 返回 Polygon 实例。
         */
        polygon(cfg?: Partial<GeometryCfg>): Polygon;
        /**
         * 创建 Point 几何标记。
         * @param [cfg] 传入 Point 构造函数的配置。
         * @returns point 返回 Point 实例。
         */
        point(cfg?: Partial<GeometryCfg>): Point;
        /**
         * 创建 Interval 几何标记。
         * @param [cfg] 传入 Interval 构造函数的配置。
         * @returns interval 返回 Interval 实例。
         */
        interval(cfg?: Partial<GeometryCfg>): Interval;
        /**
         * 创建 Schema 几何标记。
         * @param [cfg] 传入 Schema 构造函数的配置。
         * @returns schema 返回 Schema 实例。
         */
        schema(cfg?: Partial<GeometryCfg>): Schema;
        /**
         * 创建 Path 几何标记。
         * @param [cfg] 传入 Path 构造函数的配置。
         * @returns path 返回 Path 实例。
         */
        path(cfg?: Partial<PathCfg>): Path;
        /**
         * 创建 Line 几何标记。
         * @param [cfg] 传入 Line 构造函数的配置。
         * @returns line 返回 Line 实例。
         */
        line(cfg?: Partial<PathCfg>): Line;
        /**
         * 创建 Area 几何标记。
         * @param [cfg] 传入 Area 构造函数的配置。
         * @returns area 返回 Area 实例。
         */
        area(cfg?: Partial<AreaCfg>): Area;
        /**
         * 创建 Edge 几何标记。
         * @param [cfg] 传入 Edge 构造函数的配置。
         * @returns schema 返回 Edge 实例。
         */
        edge(cfg?: Partial<GeometryCfg>): Edge;
        /**
         * 创建 Heatmap 几何标记。
         * @param [cfg] 传入 Heatmap 构造函数的配置。
         * @returns heatmap 返回 Heatmap 实例。
         */
        heatmap(cfg?: Partial<GeometryCfg>): Heatmap;
    }
}
```

## 1.4 度量

scale 有很多中文名，标度、度量、比例尺等等。它是数据空间到图形空间的转换桥梁，负责将数据从数据空间（定义域）转换为图形属性空间区域（值域），下文都称为度量。

![image.png](https://b3logfile.com/file/2020/11/image-40a89e56.png)

### 通用属性

> Scale 度量模块提供了下面 3 大类的度量

* 分类度量：

  * cat： 分类度量
  * timeCat: 时间分类度量
* 连续度量：

  * linear: 线性度量
  * time：连续的时间度量
  * log: log 度量
  * pow: pow 度量
  * quantize：分段度量，用户可以指定不均匀的分段
  * quantile: 等分度量，根据数据的分布自动计算分段
* 常量度量

  * identity: 常量度量
    这些度量的使用通过 getScale 方法来获取

| 名称 | 类型 | 说明 |
| - | - | - |
| type | string | 度量 类型 |
| values | any[] | 定义域 |
| min | any | 定义域的最小值，在分类型 度量 中为序号 |
| max | any | 定义域的最大值 |
| range | [number, number] | 值域的最小、最大值 |
| tickCount | number | 期望的 tick 数量，非最终结果 |
| formatter | func(value, index) | 格式化函数，用于 tooltip、tick 等展示 |
| tickMethod | string/func(scale) | 计算 ticks 的方法 |

### 通用的 Methods

> 所有的 Scale 仅开放下面的方法，不提供任何其他方法

| 名称 | 类型 | 说明 |
| - | - | - |
| scale | (value: any): number | 将定义域的输入值转换为值域的输出值 |
| invert | (scaled: number): any | 将值域的输入值转换为定义域的输出值 |
| translate | (value: any): number | 分类型 度量 中，将定义域转化为序号 |
| clone | (): void | 复制 度量 实例 |
| getTicks | (): Tick[] | 获取所有 ticks 集合 |
| getText | (value: any): string | 获取输入值的展示结果 |
| change | (cfg) | 修改度量 |

## 1.5 坐标系

G2 提供了多种坐标系的支持：笛卡尔坐标、极坐标以及螺旋坐标等。

```ts
/** 坐标系配置 */
export interface CoordinateOption {
    /** 坐标系类型 */
    type?: 'polar' | 'theta' | 'rect' | 'cartesian' | 'helix';
    /** 坐标系配置项，目前常用于极坐标。 */
    cfg?: CoordinateCfg;
    /**
     * 坐标系变换操作:
     * 1. rotate 表示旋转，使用弧度制。
     * 2. scale 表示沿着 x 和 y 方向的缩放比率。
     * 3. reflect 表示沿 x 方向镜像或者沿 y 轴方向映射。
     * 4. transpose 表示 x，y 轴置换。
     */
    actions?: CoordinateActions[];
}
```

## 1.6 可视化组件

在 G2 中，提供了丰富的可视化组件，包括坐标轴 Axis，图例 Legend，提示信息 Tooltip，图形标记 Annotation，滑动条 Slider 等。

```chart.tooltip().axis().legend()
chart.tooltip().axis().legend()
```

## 1.7 分面

按照指定的维度划分数据集，对图表进行排版，就类似于样本对比一样

```ts
chart.facet()
```

# 2.视觉通道

* 一个数据字段对应一个视觉通道（1：1)
* 一个数据字段对应多个视觉通道（1：n)
* 多个数据字段对应一个视觉通道（n：1）

![image.png](https://b3logfile.com/file/2020/11/image-50132fa8.png)

![image.png](https://b3logfile.com/file/2020/11/image-6c638865.png)

### G2 视觉通道的设计

对应视觉编码中的视觉通道，G2 提供了以下四种**图形属性**：

| **图形属性** | **描述** |
| - | - |
| position(位置) | 二维坐标系内可以映射到 x,y，三维坐标系可以映射到 x,y,z。 |
| color（颜色) | 包含了色调、饱和度和亮度。 |
| size（大小） | 二维坐标系内可以映射到 x,y，三维坐标系可以映射到 x,y,z。 |
| shape（形状） | 图形的形状决定了某个图表类型的表现方式。例如 点图，可以使用圆点、三角形、小的图片表示；线图可以使用折线、曲线、点线等表现形式。 |

```ts
chart.point().color().position().shape().size()
```

# 2.几何图形


Shape 是 G2 中最灵活、内容最丰富的模块，下图是各个图表的 shape 实现：

| **geometry 类型** | **shape 类型** | **解释** |
| - | - | - |
| point | - 'circle'- 'square'- 'bowtie'- 'diamond'- 'hexagon'- 'triangle'- 'triangle-down'- 'hollow-circle'- 'hollow-square'- 'hollow-bowtie'- 'hollow-diamond'- 'hollow-hexagon'- 'hollow-triangle'- 'hollow-triangle-down'- 'cross'- 'tick'- 'plus'- 'hyphen'- 'line' | hollow 开头的图形都是空心的。![image.png](https://b3logfile.com/file/2020/11/solofetchupload1506768428149515580-83e9a7eb.png)![image.png](https://b3logfile.com/file/2020/11/solofetchupload496897092693170908-93780cd1.png) |
| line | - 'line'- 'dot'- 'dash'- 'smooth'- 'hv'- 'vh'- 'hvh'- 'vhv' | 'hv', 'vh', 'hvh', 'vhv' 用于绘制阶梯线图。![image.png](https://b3logfile.com/file/2020/11/solofetchupload5490280280271053348-b5cdc105.png) |
| area | - 'area'- 'smooth'- 'line'- 'smooth-line' | 'area' 和 'smooth-line' 是填充内容的区域图，其他图表是空心的线图。![image.png](https://b3logfile.com/file/2020/11/solofetchupload8692154473164664624-e443bc3e.png) |
| interval | - 'rect'- 'hollow-rect'- 'line'- 'tick'- 'funnel'- 'pyramid' | 'hollow-rect' 是空心的矩形，'line' 和 'tick' 都是线段，'funnel' 用于绘制漏斗图；'pyramid' 用于绘制金字塔图。![image.png](https://b3logfile.com/file/2020/11/solofetchupload7503349775165839166-c067968a.png) |
| polygon | - 'polygon' | polygon：多边形。![image.png](https://b3logfile.com/file/2020/11/solofetchupload6319090592525025272-8540cf61.png) |
| schema | - 'box'- 'candle' | 目前仅支持箱须图('box')、K 线图('candle')。![image.png](https://b3logfile.com/file/2020/11/solofetchupload7396679678138436868-d83d80bd.png)![image.png](https://b3logfile.com/file/2020/11/solofetchupload3512066281680240988-133eed4d.png) |
| edge | - 'line'- 'vhv'- 'smooth'- 'arc' | vhv：直角折线，arc：弧线，分为笛卡尔坐标系、极坐标系、带权重和不带权重四种情况。![image.png](https://b3logfile.com/file/2020/11/solofetchupload8799745401652385789-89c66973.png) |
