title: Python
date: '2019-08-19 09:09:27'
updated: '2019-08-19 09:12:44'
tags: [Python]
permalink: /articles/2019/08/19/1566176967608.html
---
![](https://img.hacpai.com/bing/20180723.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 前言

本文全为实例,需要自己感受代码  执行时发生了什么 ,难点会有注释,适用于有基础快速入门或者复习基础知识的人群

# 列表/元组

```
some = print(some)
```

## 通用的序列操作

### 索引

```python
greeting = 'hello'

>>greeting[0]
'h'
>>greeting[1]
'e'
```

### 切片

```python
tag = '<a href=" http://www.python.org">Python web site</a>'

>>tag[9:30]
'http://www.python.org'

>>tag[32:-4]
'Python Web Site'

numbers = [1,2,3,4,5,6,7,8,9,10]

>> numbers[3:6]
[4,5,6]

>>numbers[0:1]
[1]

>>numbers[-3:-1]
[8,9]

>>numbers[-3:]
[8,9,10]

>>numbers[:3]
[1,2,3]

>>numbers[:]
[1,2,3,4,5,6,7,8,9,10]

#步长
>>numbers[::2]
[2,4,6,8,10]

>>numbers[1::2]
[1,3,5,7,9]

>>numbers[::-2]
[10,8,6,4,2]
```

### 序列运算

```python
>> [1,2,3] + [4,5,6]
[1,2,3,4,5,6]

>>'hello,'+'world'
'hello,world'

>> 'python,'*5
'python,python,python,python,python,'
```

demo

```python
sentence = input(" Sentence: ")
screen_ width = 80
text_ width = len( sentence)
box_ width = text_ width + 6
left_ margin = (screen_ width - box_ width) // 2 print()
print(' ' * left_ margin + '+' + '-' * (box_ width- 2) + '+')
print(' ' * left_ margin + '| ' + ' ' * text_ width + ' |')
print(' ' * left_ margin + '| ' + sentence + ' |')
print(' ' * left_ margin + '| ' + ' ' * text_ width + ' |')
print(' ' * left_ margin + '+' + '-' * (box_ width- 2) + '+')
print()
```

### 成员资格

```python
>> permissions = 'rw'
>>'w' in permissions
True

>>'x' in permissions
False

```

demo

```python
usernameAndPassword = [
    ['ferried','123'],
    ['ferried2','123']
]
#获取用户输入用户名
username = input('Username :')
#获取用户输入密码
password = input('Password :')

if [username,password] in usernameAndPassword:
    print('Logined')

```

### 长度/最大值/最小值

```python
>>> numbers = [100,34,678]
>>>len(numbers)
3
>>>max(numbers)
678
>>>min(numbers)
34
>>>max(1,2,3)
3
....
```

## 列表

### list

```python
>>> list('Hello')
['H', 'e', 'l', 'l', 'o']

>>> list('Hello').join('')
'Hello'

>>> x=[1,2,3]

>>> x[1]=x[2]*3
>>> x
[1,6,3]

>>> del x[0]
>>> x
[6,3]

#切片赋值

>>> name = list('Perl')
>>> name
['P','e','r','l']

>>> name[2:] = list('ar')
>>> name
['P','e','a','r']

>>> numbers = [1,5]
>>> numbers[1:1] = [2,3,4]
>>> numbers
[1,2,3,4,5]

#切片删除
>>> numbers[1:4] = []
>>> numbers
[1,5]

#列表方法

#append
>>> numbers.append(6)
>>> numbers
[1,5,6]
#clear
>>> numbers.clear()
>>> numbers
[]
#copy
# = 符号只能内存地址引用
>>> a = [1,2,3]
>>> b = a
>>> b[0] = 4
>>> a
[4,2,3]

>>> a = [1,2,3]
>>> b = a.copy()
>>> b[0] = 4
>>> a
[1,2,3]

#count
>>> ['to', 'be', 'or', 'not', 'to', 'be'].count(' to')
2
>>> x = [[1, 2], 1, 1, [2, 1, [1, 2]]]
>>> x. count( 1)
2
>>> x. count([ 1, 2])
1

#extend
>>> a = [1, 2, 3]
>>> b = [4, 5, 6]
>>> a. extend( b)
>>> a
[1, 2, 3, 4, 5, 6]

#index
>>> knights = ['We', 'are', 'the', 'knights', 'who', 'say', 'ni']
>>> knights. index(' who')
4
>>> knights. index(' herring')
Traceback (innermost last):
File "<pyshell>", line 1, in ? knights. index(' herring')
ValueError: list. index( x): x not in list

#insert
>>> [1,2,3].insert(3,4)
>>> [1,2,3,4]

#pop
>>> x = [1,2,3]
>>> x.pop()
3
>>> x
>>> [1,2]

#remove
>>> x = ['to', 'be', 'or', 'not', 'to', 'be']
>>> x.remove(' be')
>>> x
['to', 'or', 'not', 'to', 'be']
>>> x.remove(' bee')
Traceback (innermost last):
File "<pyshell>", line 1, in ? x. remove(' bee') ValueError: list. remove( x): x not in list

#reverse
>>>[1,2,3].reverse()
[3,2,1]

#sort
>>>[3,1,2].sort()
[1,2,3]

```

## 元组

不可改变的列表
(和,是元组的标志

```python
>>> 1,2,3
(1,2,3)

>>> tuple([ 1, 2, 3]) (1, 2, 3)
>>> tuple(' abc') ('a', 'b', 'c')
>>> tuple(( 1, 2, 3)) (1, 2, 3)
```

# 字符串

字符串也是序列的一种,但是字符串是不可变的

```python
>>> website='http://www.python.org'
>>> website[-3:] = 'com'
错误
>>> new_website = website[-3:]+'com'
http://www.pygthon.com
```

## 字符串格式化

```python
>>> format = "Hello,%s %s enough for ya ?"
>>> values = ('world','Hot')
>>> format % values
Hello world hot enough for ya ?

>>> "{} {} and {}".format("1","2","3")
'1 2 and 3"

>>> "{0}{1}{2}".format("1","2","3")
"123"

>>> "{1}{0}{2}".format("1","2","3")
"213"

# .2f = 0.00 .5f = 0.00000
>>> from math import pi
>>> "{name} is approximately {value:.2f}".format(value = pi,name = 'π')

π is approximately 3.14

# f
>>> from math import e
>>> f"asdf{e}"
"asdf 2. 718281828459045."

```

## 字符串函数

```python
#center
>>> "The Middle by Jimmy Eat World".center( 39) ' The Middle by Jimmy Eat World '
>>> "The Middle by Jimmy Eat World".center( 39, "*")
'*****The Middle by Jimmy Eat World*****'
#find
>>> "With a moo-moo here,and a moo-moo there'.find('moo')
7
#join
>>> seq = ['1','2','3','4','5']
>>> seq.join('+')
'1+2+3+4+5'

#lower(小写)
#title/string.capwords(词首大写)

#replace
>>> 'This is a test'.replace(' is', 'eez') 'Theez eez a test'

#split
>>> '1+ 2+ 3+ 4+ 5'.split('+')
['1', '2', '3', '4', '5']

#strip
>>> ' a b '.strip()
'a b'

#字符串判断
#isalnum、 isalpha、 isdecimal、 isdigit、 isidentifier、 islower、 isnumeric、 isprintable、 isspace、 istitle、 isupper。

```

# 字典

key-value

##  创建方法

```python
phonebook = {'Alice': '2341', 'Beth': '9102', 'Cecil': '3258'}

>>> items = [('name', 'Gumby'), ('age', 42)]
>>> d = dict( items)
>>> d {'age': 42, 'name': 'Gumby'}
>>> d[' name']
'Gumby'

>>> d = dict(name='haha',age=42)
>>> d
{'age':42,name:'haha'}

```

## 基本操作

```
len( d): 返回 字典 d 包含 的 项（ 键- 值 对） 数。
d[ k]: 返回 与 键 k 相 关联 的 值。
d[ k] = v: 将 值 v 关联 到 键 k。
del d[ k]: 删除 键 为 k 的 项。
k in d: 检查 字典 d 是否 包含 键 为 k 的 项。
```

## api

```python
#clear()
#copy()
#deepcopy():拷贝字典中所有值
#fromkeys():获取所有key
#get('key'):获取相应key的value(不会抛异常)
#items
>>> d = {'title': 'Python Web Site', 'url': 'http:// www. python. org', 'spam': 0}
>>> d.items()
dict_ items([(' url', 'http:// www. python. org'), ('spam', 0), ('title', 'Python Web Site')])
#keys():返回所有key
#pop('key'):删除对应key元素
#popitem:删除末尾元素
#setdefault('key','value'):设置key的默认值为value
#update():a.update(b)用a更新字典b同key替换
#values():返回所有value

```

# 条件分支/其他语句

## 序列解包

```python
>>> x,y,z = 1,2,3
>>> x,y,*z = 1,2,3,4,5,6
>>> z
[3,4,5,6]

>>> a,b = 1,2
#swap
>>> a,b = b,a
>>> scoundrel = {'name': 'Robin', 'girlfriend': 'Marion'}
>>> key, value = scoundrel. popitem()
>>> key
'girlfriend'

```

## if

```python
#假False None 0 "" () [] {}
#True 为 1 False 为 0

name = input('What is your name?')
if name.endsWith('Cui'):
    print('Hello {}'.format(name))
else:
    print('Hello,stranger')

#二目
status = "friend" if name.endsWith("Gumby") else "stranger"

num = input("please input a number:")
if num > 0:
    print("{}>0".format(num))
elif num < 0:
    print("{}<0".format(num))
else
    print("{}=0".format(num))
# if in or and == != < > >= <= && ||
```

## for

```python
x = 1
while x <= 100:
    x+=1

words = ["this","is","an","ex","parrot"]
for word in words:
    print(word)

for number in list(range(0,10)):
    print(number*number)

for number in list(range(0,10))[0,2]:
    print(number)
#dic
d = {'x': 1, 'y': 2, 'z': 3}
for key in d:
    print(key,d[key])

for key,value in d.items():
    print(key,value)

#zip
names = ['anne', 'beth', 'george', 'damon']
ages = [12, 45, 32, 102]

for name,age in zip(names,ages):
    print(...)

#index
for index,string in enumerate("asdf"):
    if 'x' in string:
        string[index]='[y]'
```

## break

```python
#break 跳出循环
#sqrt = 平方根
from math import sqrt

for n in range(99,0,-1):
    root = sqrt(n)
    if root == int(root):
        print(n)
        break
```

## continue

```python
for x in range(0,10):
    if x%2 == 0:
        continue
    else
        print(x)
```

## 推导

```python
# 1-9 1*1 2*2 3*3 4*4 ...
>>> [x * x for x in range(0,10)]
[0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

#1-9 x*x%3==0
>>> [ x * x from x in range(10) if x%3 == 0 ]

#排列组合
>>> [(x,y) for x in range(3) for y in range(3)]
[(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)]

#男孩找女孩
>>> girls = ['alice', 'bernice', 'clarice']
>>> boys = ['chris', 'arnold', 'bob']
>>> [b+'+'+g for b in boys for g in girls if b[0]==g[0]]

['chris+ clarice', 'arnold+ alice', 'bob+ bernice']

#更好的解决方案
girls = ['alice', 'bernice', 'clarice']
boys = ['chris', 'arnold', 'bob']
letterGirls = {}
for girl in girls:
    letterGirls. setdefault( girl[ 0], []).append( girl)
print([ b+'+'+ g for b in boys for g in letterGirls[ b[ 0]]])
```

# 函数

##  传统参数

```python
def fun1(name,age,value):
    print(name,age,value)

fun1('a',10,1)
```

## 关键字参数/默认值

```python
def fun2(name = 'default', age = '0',value):
    print(name,age,value)

fun2(name = 'wa',value = 10,age='11')
```

## 可变参

```python
def fun3(*names):
    print(names)

fun3('a','b','c','d')


def fun4(x,*y,z):
    print(x,y,z)

fun4(4,1,2,3,4,z=7)

def fun5(**params):
    print(params)

fun5(x=1,y=2,z=3)

>>> {'z': 3, 'x': 1, 'y': 2}
```

demo

```python
def store(data,*full_names):
    for full_name in full_names:
        names = full_name.split()
        if len(names)  == 2:
            names.insert(1,'')
        labels = 'first','middle','last'
        for label, name in zip(labels,names):
            people = lookup(data,label,name)
            if people:
                people.append(full_name)
            else:
                data[label][name] = [full_name]
```

| name | desc|
|-|-|
|map( func, seq[, seq, ...])| 对 序列 中的 所有 元素 执行 函数 
|filter( func, seq)| 返回 一个 列表， 其中 包含 对其 执行 函数 时 结果 为真 的 所有 元素|
| reduce( func, seq[, initial]) | 等价 于 func( func( func( seq[ 0], seq[ 1]), seq[ 2]), ...) |
| sum( seq)| 返回 seq 中 所有 元素 的 和|
  |apply( func[, args[, kwargs]])| 调用 函数（ 还 提供 要 传递 给 函数 的 参数）|


# 异常

引发异常可以通过raise语句指定一个异常类，类必须为Exception的子类

```python
>>> raise Exception
```

## 内置异常类

```python
Exception: 各种异常类的父类
AttributeError: 引用属性或者赋值失败时引发的异常
OSError: 操作系统不能执行指定任务时引发
IndexError: 数组索引错误时触发 LookupError的子类
KeyError: 使用映射中不存在的键时 LookupError的子类
NameError: 找不到名称时
SyntaxError: 代码格式不正确时
TypeError: 将内置操作或函数用于不正确的对象是引发
ValueError: 值的类型不符合内置操作或函数
ZeroDivisionError: 被除数为0的时候触发
```

## 自定义异常类

```python
class SomeCustomException(Exception):
    pass
```

## 捕获异常

```python
x = int(input('enter the first number'))
y = int(input('enter the second number'))
print(x/y)

>> 10/0 
File "exceptions. py", line 3, in ? 
print( x / y) 
ZeroDivisionError: integer division or modulo by zero

```

### 向上传播

raise 不指定任何参数

```python
class MuffledCalculator:
    muffed = False
    def calc(self,expr):
        try:
            return eval(expr)
        except ZeroDivisionError:
            if self.muffed:
                print()
            else:
                # 条件不符合直接向上抛出异常
                raise
```

### 多个except

```python
try:
    x = int(input('input a number'))
    y = int(input('input another number '))
except ZeroDivisionError:
    print('error 1')
except TypeError:
    print('error 2')
```

```python

try:
    x = int(input('input a number'))
    y = int(input('input another number '))
except (ZeroDivisionError,TypeError):
    print('error 1')
```

### 捕获对象

```python

```





